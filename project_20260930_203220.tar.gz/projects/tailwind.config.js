/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'media',
  theme: {
    extend: {
      colors: {
        lacquer: {
          DEFAULT: '#15100C',
          deep: '#0D0906',
          soft: '#221A14',
          line: '#3A2E23',
        },
        tibetan: {
          DEFAULT: '#9E2B25',
          deep: '#731C19',
          bright: '#C0392B',
        },
        imperial: {
          DEFAULT: '#E8B84B',
          soft: '#F2D078',
          deep: '#C8923A',
        },
        celadon: {
          DEFAULT: '#B9C7C6',
          soft: '#D7E0DE',
          deep: '#8FA2A1',
        },
        paper: '#F4ECD8',
      },
      fontFamily: {
        cal: ['"Ma Shan Zheng"', 'cursive'],
        deco: ['"ZCOOL XiaoWei"', 'serif'],
        sans: ['"Noto Sans SC"', 'system-ui', 'sans-serif'],
      },
      transitionTimingFunction: {
        ritual: 'cubic-bezier(0.22, 1, 0.36, 1)',
      },
    },
  },
  plugins: [],
};
