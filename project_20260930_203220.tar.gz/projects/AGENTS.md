# AGENTS.md

## 项目概览

「山海纹叙——藏彝民族传统纹样数字交互展厅」，数媒大赛参赛作品（民族文化创新表达赛道）。横向滚动叙事单页应用（6 大板块），核心为彝族漆器纹样与藏族吉祥八宝纹样的双民族对比、纹样分层解构与再创作。纯静态前端，零后端：产物为 Vite 构建出的 `dist/` 静态文件，可直接部署到任意静态托管。

## 技术栈

- 构建：Vite 7 + TypeScript 5（strict）
- 视图：React 19（`@vitejs/plugin-react@4`）
- 样式：Tailwind CSS 3（主题见 `tailwind.config.js`）
- 导出：html2canvas（工坊画板导出 PNG）
- 视觉巡检：playwright-core（`scripts/*check*.mjs`，仅开发期自检，不入运行依赖）

## 目录结构

```
├── scripts/            # 构建/启动脚本 + 自检脚本
│   ├── dev.sh            # 启动 Vite dev server（HMR，端口读 DEPLOY_RUN_PORT）
│   ├── build.sh          # vite build → dist/
│   ├── start.sh / serve.sh / serve.mjs  # 零依赖 Node 静态服务器托管 dist/（含 SPA 回退）
│   ├── visual-check.mjs        # 逐页截图 + 溢出/裁切检测
│   ├── interaction-check.mjs   # 核心交互断言（拆解/双视图/时间轴/工坊）
│   ├── vision-*.mjs            # 多模态模型视觉评审
│   └── dom-check.mjs / find404.mjs
├── dist/               # 纯静态构建产物（部署物）
├── src/
│   ├── entry.tsx       # React 挂载入口（StrictMode）
│   ├── App.tsx         # 横向滚动主轴：page state、hash 同步、滚轮/触摸/键盘翻页
│   ├── index.css       # Tailwind + 自定义动效/纹理/字体
│   └── components/
│       ├── NavDots.tsx / Modal.tsx / PageHeader.tsx
│       ├── DeconstructCanvas.tsx        # 分层拆解画布（散开/点选/重组）
│       ├── patterns/                    # 程序化 SVG 纹样库
│       │   ├── types.ts                 # PatternDef / Layer / Stage 类型与 stageVars
│       │   ├── YiPatterns.tsx           # 彝族：虎/火/牛角/回旋几何
│       │   ├── TbPatterns.tsx           # 藏族：八宝符号
│       │   └── PatternView.tsx
│       └── pages/                       # 六个板块
│           ├── CoverPage.tsx            # P1 封面
│           ├── OriginPage.tsx + artifacts.tsx  # P2 文化溯源
│           ├── LabPage.tsx              # P3 解构实验室
│           ├── WorkshopPage.tsx + FragmentArt.tsx  # P4 再创作工坊
│           ├── ApplicationPage.tsx      # P5 现代应用样机
│           └── EndingPage.tsx           # P6 尾页
├── index.html
├── tailwind.config.js
└── vite.config.ts
```

## 常用命令（仅用 pnpm）

- 安装依赖：`pnpm install`
- 类型检查：`pnpm ts-check`
- Lint：`pnpm lint`
- 开发：`pnpm run dev`（端口读 `DEPLOY_RUN_PORT`，主仓 5000）
- 构建：`pnpm run build`（纯静态产物 → `dist/`）
- 静态托管（生产）：`bash scripts/start.sh`（零依赖 Node 服务器托管 `dist/`，端口读 `DEPLOY_RUN_PORT`）
- 交互自检：`node scripts/interaction-check.mjs`（需开发服务器运行）

## 核心实现约定

- **横向滚动**：`App.tsx` 中 `page` state 驱动长卷 `translate3d(-page*100vw)`；支持滚轮纵向转横向、触摸、键盘 ←/→、导航圆点。
- **hash 单一数据源**：`hashchange` 监听 + 挂载初始化，保证分享链接、浏览器前进/后退、同源 hash 导航均能正确定位（勿退化成只在挂载 effect 读一次 hash）。
- **纹样全部程序化 SVG**：无外部图片依赖。每个纹样实现为 `PatternDef`（含 3 个 `Layer`：轮廓/填充/装饰），`Stage`（0 古器原图 / 1 线稿 / 2 矢量）通过 CSS 变量切换外观。
- **拆解交互**：`DeconstructCanvas` 点击整图令各层沿 `SCATTER` 方向 translate 散开并显示引线标签；点选单层高亮、其余变暗；重组归零。
- **工坊**：HTML5 拖放 + pointer 移动，支持缩放/旋转/三配色，html2canvas 导出画板。

## 编码规范

- TypeScript strict；禁止隐式 `any` 与 `as any`；函数参数、事件对象、`req`/`res`、catch 错误需明确类型并完成收窄。
- React 17+ 不引 React 默认导出（仅在需要命名空间时 `import type`）；组件用 PascalCase，文件名与组件对应。
- 使用 Tailwind 类做样式；标点半角；及时清理未使用的变量与导入。

## 设计规范

视觉、配色、字体、动效的长期约定见根目录 `DESIGN.md`。
