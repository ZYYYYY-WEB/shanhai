import fs from 'node:fs';
import { join } from 'node:path';
import { LLMClient, Config } from 'coze-coding-dev-sdk';

const dir = '/tmp/shots';
const tasks = [
  ['final-p3.png', '这是纹样拆解后的画面。请确认：每个分层标签（轮廓层/填充层/装饰层及说明小字）是否完整显示在带边框的小方框内，有无文字超出方框或被裁切？只回答有无超出/裁切并指出。'],
  ['final-p4.png', '这是再创作工坊页面。请确认顶部标题「再创作工坊」这5个字是否在同一行完整显示（没有换行或遮挡）？只回答结论。'],
  ['final-p6.png', '这是尾页。请逐字抄录页面上「小组成员」和「参赛赛道」相关的所有文字。'],
];

const client = new LLMClient(new Config());
for (const [file, prompt] of tasks) {
  const buf = fs.readFileSync(join(dir, file));
  const res = await client.invoke(
    [
      {
        role: 'user',
        content: [
          { type: 'text', text: prompt },
          { type: 'image_url', image_url: { url: `data:image/png;base64,${buf.toString('base64')}`, detail: 'high' } },
        ],
      },
    ],
    { model: 'doubao-seed-2-0-pro-260215', temperature: 0.1 }
  );
  console.log(`\n===== ${file} =====\n${res.content}`);
}
