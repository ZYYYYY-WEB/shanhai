import fs from "node:fs";
import { LLMClient, Config } from "coze-coding-dev-sdk";

const b64 = fs.readFileSync("/tmp/shots/fonts.png").toString("base64");
const prompt =
  "图片中用不同中文字体渲染了\"山海纹叙\"（A-G 七种），底部还有三个放大的单字\"叙\"（A/B/D）。"
  + "规范简体字\"叙\"的写法：左半为\"余\"——上面是人字头(撇、捺)，下面是\"禾\"；右半是\"又\"。"
  + "繁体\"敘\"或异体的左半下部结构不同，且笔画可能出头。请逐行判断 A-G 七种字体里的\"叙\"是否为规范简体字形"
  + "（重点：左半是否为规范的\"余\"，人字头捺笔、下部\"禾\"有无多余出头笔画），列出哪些字体规范、哪些不规范。"
  + "然后在规范字体里，推荐一种最具东方书法/古典气质、适合做民族文化展厅大标题的字体，并说明理由。只给结论，不要寒暄。";

const content = [
  { type: "text", text: prompt },
  { type: "image_url", image_url: { url: `data:image/png;base64,${b64}`, detail: "high" } },
];
const client = new LLMClient(new Config());
const res = await client.invoke(
  [{ role: "user", content }],
  { model: "doubao-seed-2-0-pro-260215", temperature: 0.2 }
);
console.log(res.content);
