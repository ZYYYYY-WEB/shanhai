import { LLMClient, Config } from "coze-coding-dev-sdk";
import fs from "node:fs";

const files = ["p1-cover.png", "p3-lab.png", "p6-ending.png"];
const content = [
  {
    type: "text",
    text: "对每张截图，用一句话回答：1) 屏幕中央最大的标题文字是什么？2) 底部导航圆点共有几个、第几个处于高亮（实心/放大）状态？3) 屏幕底部偏左是否有『向右滑动·启卷』字样与箭头？请按截图顺序简洁回答。",
  },
];
for (const f of files) {
  const buf = fs.readFileSync(`/tmp/shots/${f}`);
  content.push({ type: "text", text: `===== ${f} =====` });
  content.push({
    type: "image_url",
    image_url: { url: `data:image/png;base64,${buf.toString("base64")}`, detail: "high" },
  });
}
const client = new LLMClient(new Config());
const res = await client.invoke(
  [{ role: "user", content }],
  { model: "doubao-seed-2-0-pro-260215", temperature: 0.1 }
);
console.log(res.content);
