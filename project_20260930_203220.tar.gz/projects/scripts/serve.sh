#!/bin/bash
set -Eeuo pipefail

COZE_WORKSPACE_PATH="${COZE_WORKSPACE_PATH:-$(pwd)}"
cd "${COZE_WORKSPACE_PATH}"

PORT=5000
DEPLOY_RUN_PORT="${DEPLOY_RUN_PORT:-$PORT}"

# 部署流程已单独执行 build；若产物缺失（本地直接 run），则先构建。
if [ ! -d "${COZE_WORKSPACE_PATH}/dist" ]; then
  echo "dist/ not found, building static assets..."
  bash "${COZE_WORKSPACE_PATH}/scripts/build.sh"
fi

echo "Starting static file server on port ${DEPLOY_RUN_PORT}..."
DEPLOY_RUN_PORT="${DEPLOY_RUN_PORT}" exec node scripts/serve.mjs
