import { chromium } from 'playwright-core';

const browser = await chromium.launch({
  executablePath: '/root/.cache/ms-playwright/chromium-1161/chrome-linux/chrome',
  args: ['--no-sandbox'],
});
const page = await browser.newPage();
page.on('response', (res) => {
  if (res.status() === 404) console.log('404 ->', res.url());
});
await page.goto('http://localhost:5000/#0', { waitUntil: 'networkidle' });
await page.waitForTimeout(1500);
await browser.close();
