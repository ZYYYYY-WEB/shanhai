import { chromium } from 'playwright-core';

const CHROME = '/root/.cache/ms-playwright/chromium-1161/chrome-linux/chrome';
const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
page.on('pageerror', (e) => {
  if (!/WebSocket/.test(e.message)) console.log('PAGEERROR:', e.message);
});

const results = [];
const check = (name, cond, extra = '') => results.push(`${cond ? 'PASS' : 'FAIL'} | ${name}${extra ? ` | ${extra}` : ''}`);

// ---------- P3 解构实验室 ----------
await page.goto('http://localhost:5000/#2', { waitUntil: 'networkidle' });
await page.waitForTimeout(1800);

const canvasBtn = () => page.locator('button[aria-label="拆解纹样"], button[aria-label="重组纹样"]');
check('初始单视图画布数=1', (await canvasBtn().count()) === 1);

// 拆解：点击整图按钮
await canvasBtn().first().click();
await page.waitForTimeout(900);
// 散开判定：层 <g> 出现非零 translate
let transforms = await page.locator('svg g[role="button"]').evaluateAll((gs) =>
  gs.map((g) => g.style.transform),
);
let exploded = transforms.some((t) => /translate\((?!0)/.test(t));
check('点击后各层 translate 散开', exploded, transforms.join(' / '));

// 解说文案
const bodyText1 = await page.locator('body').innerText();
check('拆解解说出现', /图腾|驱邪|护佑|永恒|吉祥|火|丰收/.test(bodyText1));

// 点选单层（在散开态点击第一个 g）
await page.locator('svg g[role="button"]').first().click({ force: true });
await page.waitForTimeout(500);
// 激活态：其它层变暗（存在 opacity 0.25）
const hasDimmed = await page.locator('svg g[role="button"]').evaluateAll((gs) =>
  gs.some((g) => g.style.opacity === '0.25'),
);
const layerNameShown = await page.locator('body').innerText();
check('点选局部层高亮/其余变暗', hasDimmed);

// 重组（点按钮边角，避免落到内部 SVG <g>）
await page.locator('button[aria-label="重组纹样"]').first().click({ position: { x: 12, y: 12 } });
await page.waitForTimeout(1000);
transforms = await page.locator('svg g[role="button"]').evaluateAll((gs) => gs.map((g) => g.style.transform));
check('重组后各层回归 translate(0)', transforms.every((t) => /translate\(0px, 0px\)/.test(t)), transforms.join(' / '));

// 双视图
await page.getByRole('button', { name: /双视图|对比|并排/ }).first().click();
await page.waitForTimeout(800);
check('双视图出现2画布', (await canvasBtn().count()) === 2);

// 时间轴
const slider = page.locator('input[type="range"]').first();
const box = await slider.boundingBox();
await page.mouse.move(box.x + box.width * 0.2, box.y + box.height / 2);
await page.mouse.down();
await page.mouse.move(box.x + box.width * 0.95, box.y + box.height / 2, { steps: 8 });
await page.mouse.up();
await page.waitForTimeout(600);
check('时间轴拖动出现演变阶段', /线稿|矢量|简化|提取|演变/.test(await page.locator('body').innerText()));

// ---------- P2 器物 hover/点击 ----------
await page.goto('http://localhost:5000/#1', { waitUntil: 'networkidle' });
await page.waitForTimeout(1600);
const cards = page.locator('button.group.relative');
const cardCount = await cards.count();
check('器物卡片存在（>=6）', cardCount >= 6, `count=${cardCount}`);
const card = cards.first();
await card.hover();
await page.waitForTimeout(500);
// 注释 tooltip 变可见
const tipVisible = await page.locator('button.group span.pointer-events-none').first().evaluate(
  (el) => getComputedStyle(el).opacity,
);
check('hover 器物注释 opacity=1', tipVisible === '1', `opacity=${tipVisible}`);
await card.click();
await page.waitForTimeout(700);
check('点击器物弹出 dialog', (await page.locator('[role="dialog"]').count()) >= 1);
await page.keyboard.press('Escape');
await page.waitForTimeout(400);

// ---------- P4 工坊 ----------
await page.goto('http://localhost:5000/#3', { waitUntil: 'networkidle' });
await page.waitForTimeout(1800);
const fragButtons = page.locator('[data-no-slide] button[draggable="true"]');
check('素材碎片存在（5个）', (await fragButtons.count()) === 5, `count=${await fragButtons.count()}`);

// 点击碎片 -> 添加到画板（实现同时绑定 onClick）
await fragButtons.nth(1).click();
await fragButtons.nth(2).click();
await page.waitForTimeout(600);
const placed = page.locator('.canvas-board > div[role="button"]');
let placedCount = await placed.count();
check('碎片加入画板（>=2）', placedCount >= 2, `count=${placedCount}`);

// 选中元素
if (placedCount > 0) {
  const handle = page.locator('.canvas-board > div[role="button"]').first();
  const itemBox = await handle.boundingBox();
  // 用真实鼠标点击元素内部（SVG 位于中心会拦截，故取顶部边缘内侧，事件冒泡到父 div）。
  await page.mouse.click(itemBox.x + itemBox.width / 2, itemBox.y + 3);
  await page.waitForTimeout(400);
  const rings = await page.evaluate(() =>
    Array.from(document.querySelectorAll('.canvas-board > div[role="button"]')).map((el) => el.style.outline)
  );
  check('点选元素出现选中虚线框', rings.some((r) => /dashed/.test(r)), rings.join(' | '));

  // 旋转/缩放控件存在
  const hasControls = await page.locator('body').innerText();
  check('缩放/旋转控件可用', /旋转|缩放|角度|大小/.test(hasControls));
}

// 配色切换（限定在素材库列内）
const paletteBtn = page.locator('[data-no-slide]').getByRole('button', { name: /藏彩/ }).first();
const bgBefore = await page.locator('.canvas-board').evaluate((el) => el.style.backgroundColor);
await paletteBtn.click({ force: true });
await page.waitForTimeout(400);
const bgAfter = await page.locator('.canvas-board').evaluate((el) => el.style.backgroundColor);
check('配色方案可切换（画板底色变化）', bgBefore !== bgAfter, `${bgBefore} -> ${bgAfter}`);

// 保存按钮存在（不真正触发下载，仅验证启用）
const saveBtn = page.getByRole('button', { name: /保存|导出|下载/ });
check('保存图片按钮存在', (await saveBtn.count()) >= 1);

console.log('\n===== 交互测试结果 =====');
results.forEach((r) => console.log(r));
const failed = results.filter((r) => r.startsWith('FAIL')).length;
console.log(`\n通过 ${results.length - failed}/${results.length}`);
await browser.close();
process.exit(failed > 0 ? 1 : 0);
