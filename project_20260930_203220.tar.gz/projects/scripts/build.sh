#!/bin/bash
set -Eeuo pipefail

COZE_WORKSPACE_PATH="${COZE_WORKSPACE_PATH:-$(pwd)}"

cd "${COZE_WORKSPACE_PATH}"

echo "Installing dependencies..."
bash "$COZE_WORKSPACE_PATH/scripts/prepare-node-modules.sh" --prefer-frozen-lockfile --prefer-offline --loglevel debug --reporter=append-only

echo "Building static frontend with Vite..."
# 离线沙箱中 caniuse-lite 数据无法更新，屏蔽其数据过期的非错误性提示。
BROWSERSLIST_IGNORE_OLD_DATA=1 pnpm vite build

echo "Static build completed: dist/"
