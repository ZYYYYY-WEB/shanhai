// 纯静态文件服务器：托管 Vite 构建产物 dist/，无后端依赖。
import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';

const root = process.env.COZE_WORKSPACE_PATH || process.cwd();
const distDir = join(root, 'dist');
const port = Number(process.env.DEPLOY_RUN_PORT || 5000);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.map': 'application/json',
};

const server = createServer((req, res) => {
  const respond = (status, body, type) => {
    res.writeHead(status, {
      'Content-Type': type || 'application/octet-stream',
      'Cache-Control': 'no-cache',
    });
    res.end(body);
  };

  (async () => {
    try {
      const urlPath = decodeURIComponent(new URL(req.url || '/', 'http://x').pathname);
      const safePath = normalize(urlPath).replace(/^(\.\.[/\\])+/, '');
      let filePath = join(distDir, safePath);

      // 防止路径穿越：解析后必须仍在 dist 内。
      if (!filePath.startsWith(distDir)) {
        respond(403, 'Forbidden', 'text/plain');
        return;
      }

      let data;
      try {
        data = await readFile(filePath);
      } catch {
        // 文件不存在：目录或未知路径一律回退到 SPA 入口 index.html。
        filePath = join(distDir, 'index.html');
        data = await readFile(filePath);
      }

      respond(200, data, MIME[extname(filePath).toLowerCase()]);
    } catch (err) {
      console.error('[static-server] error:', err);
      respond(500, 'Internal Server Error', 'text/plain');
    }
  })();
});

server.listen(port, '0.0.0.0', () => {
  console.log(`[static-server] serving ${distDir} on http://0.0.0.0:${port}`);
});

// 优雅退出，避免端口泄漏。
for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    server.close(() => process.exit(0));
  });
}
