import { LLMClient, Config } from "coze-coding-dev-sdk";
import fs from "node:fs";

const buf = fs.readFileSync("/tmp/shots/p6-ending.png");
const res = await new LLMClient(new Config()).invoke(
  [
    {
      role: "user",
      content: [
        {
          type: "text",
          text: "请按从上到下的空间顺序，逐字抄录这张截图里出现的全部中文与英文文字（包括小字、标题、按钮、底部信息），不要脑补、不要猜测看不清的字，看不清就标注[模糊]。并用坐标描述最大标题在屏幕中的大致位置（上/中/下、左/中/右）。",
        },
        { type: "image_url", image_url: { url: `data:image/png;base64,${buf.toString("base64")}`, detail: "high" } },
      ],
    },
  ],
  { model: "doubao-seed-2-0-pro-260215", temperature: 0.1 }
);
console.log(res.content);
