import { chromium } from 'playwright-core';

const CHROME = '/root/.cache/ms-playwright/chromium-1161/chrome-linux/chrome';
const BASE = 'http://localhost:5000';

const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

const errors = [];
page.on('console', (msg) => {
  if (msg.type() === 'error' && !msg.text().includes('websocket') && !msg.text().includes('WebSocket')) {
    errors.push(`console.error: ${msg.text()}`);
  }
});
page.on('pageerror', (err) => {
  if (!err.message.includes('WebSocket')) errors.push(`pageerror: ${err.message}`);
});
page.on('response', (res) => {
  if (res.status() === 404) errors.push(`404: ${res.url()}`);
});

const LABELS = ['封面', '溯源', '实验室', '工坊', '应用', '结语'];

for (let i = 0; i < 6; i += 1) {
  await page.goto(`${BASE}/#${i}`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(2200);
  await page.screenshot({ path: `/tmp/shots/page${i}.png` });

  const result = await page.evaluate((idx) => {
    const sections = document.querySelectorAll('section');
    const active = sections[idx];
    if (!active) return { missing: true, overflow: [], clipped: [] };
    const sr = active.getBoundingClientRect();
    const overflow = [];
    const clipped = [];
    active.querySelectorAll('*').forEach((el) => {
      if (el.closest('[data-decor]')) return;
      const r = el.getBoundingClientRect();
      if (r.width === 0 && r.height === 0) return;
      const overR = r.right - sr.right;
      const overB = r.bottom - sr.bottom;
      const cls = String(
        el.className && el.className.baseVal !== undefined ? el.className.baseVal : el.className,
      ).slice(0, 55);
      if (overR > 3) overflow.push(`${el.tagName} +${Math.round(overR)}px :: ${cls}`);
      if (overB > 3) clipped.push(`${el.tagName} +${Math.round(overB)}px :: ${cls}`);
    });
    return { overflow: overflow.slice(0, 8), clipped: clipped.slice(0, 8) };
  }, i);

  console.log(`[${i} ${LABELS[i]}] overflow=${result.overflow.length} clipped=${result.clipped.length}`);
  result.overflow.forEach((m) => console.log(`   X ${m}`));
  result.clipped.forEach((m) => console.log(`   Y ${m}`));
}

console.log(`\nErrors/404: ${errors.length}`);
[...new Set(errors)].slice(0, 10).forEach((e) => console.log(' -', e));
await browser.close();
