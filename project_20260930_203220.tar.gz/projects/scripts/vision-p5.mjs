import { LLMClient, Config } from "coze-coding-dev-sdk";
import fs from "node:fs";
const buf = fs.readFileSync("/tmp/shots/p5-recheck.png");
const res = await new LLMClient(new Config()).invoke(
  [
    {
      role: "user",
      content: [
        { type: "text", text: "这是现代应用展示页，共4个样机卡片（文创书签、手机壳、展览海报、服饰印花）。重点检查第3张『展览海报』卡片底部的小字『藏彝纹样数字展厅』是否完整显示、有无被边框裁切半个字符。再检查整体有无其他文字裁切/重叠/溢出。简洁回答。" },
        { type: "image_url", image_url: { url: `data:image/png;base64,${buf.toString("base64")}`, detail: "high" } },
      ],
    },
  ],
  { model: "doubao-seed-2-0-pro-260215", temperature: 0.1 }
);
console.log(res.content);
