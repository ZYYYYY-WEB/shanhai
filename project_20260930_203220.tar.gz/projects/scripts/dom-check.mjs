import { chromium } from 'playwright-core';

const CHROME = '/root/.cache/ms-playwright/chromium-1161/chrome-linux/chrome';
const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

for (let i = 0; i < 6; i += 1) {
  await page.goto(`http://localhost:5000/#${i}`, { waitUntil: 'networkidle' });
  await page.waitForTimeout(1800);
  const info = await page.evaluate(() => {
    const dots = [...document.querySelectorAll('[data-dot]')].map((d) => d.getAttribute('data-dot-active'));
    const center = document.elementFromPoint(720, 420);
    const secTexts = [...document.querySelectorAll('section')].map((s, idx) => {
      const r = s.getBoundingClientRect();
      const visible = r.left < window.innerWidth && r.right > 0;
      return `${idx}:${visible ? 'VIS' : 'off'}:${(s.textContent || '').replace(/\s+/g, '').slice(0, 24)}`;
    });
    return {
      dots,
      centerTag: center?.tagName,
      centerText: (center?.textContent || '').replace(/\s+/g, '').slice(0, 40),
      secTexts,
    };
  });
  console.log(`#${i}`, JSON.stringify(info));
}
await browser.close();
