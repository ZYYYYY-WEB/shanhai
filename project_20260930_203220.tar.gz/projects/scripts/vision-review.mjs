import { LLMClient, Config } from "coze-coding-dev-sdk";
import fs from "node:fs";

const pages = [
  { file: "p1-cover.png", name: "P1 封面" },
  { file: "p2-origin.png", name: "P2 文化溯源" },
  { file: "p3-lab.png", name: "P3 解构实验室" },
  { file: "p4-workshop.png", name: "P4 再创作工坊" },
  { file: "p5-application.png", name: "P5 现代应用" },
  { file: "p6-ending.png", name: "P6 尾页" },
];

const content = [
  {
    type: "text",
    text: "你是严苛的网页视觉评审，正在评审一个横向滚动的民族纹样数字展厅参赛网站（1440x900 视口）。下面 6 张截图依次是 P1~P6 六个全屏板块。请逐页检查并只报告【确实存在的视觉缺陷】：1) 文字/元素重叠或互相遮挡；2) 内容超出容器或被裁切；3) 大面积空白、元素错位、对齐混乱；4) 文字与背景对比度不足难以辨认；5) SVG 图形渲染残缺变形。若某页没有明显缺陷，明确写『无明显缺陷』。不要泛泛夸奖，输出要具体到位置。最后给一句总体结论。",
  },
];

for (const p of pages) {
  const buf = fs.readFileSync(`/tmp/shots/${p.file}`);
  content.push({
    type: "text",
    text: `===== 截图：${p.name} =====`,
  });
  content.push({
    type: "image_url",
    image_url: { url: `data:image/png;base64,${buf.toString("base64")}`, detail: "high" },
  });
}

const client = new LLMClient(new Config());
const res = await client.invoke(
  [{ role: "user", content }],
  { model: "doubao-seed-2-0-pro-260215", temperature: 0.3 }
);
console.log(res.content);
