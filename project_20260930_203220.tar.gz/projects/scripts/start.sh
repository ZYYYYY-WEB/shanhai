#!/bin/bash
set -Eeuo pipefail

# 兼容旧入口：纯静态版本统一走 serve.sh（托管 Vite 构建产物 dist/）。
exec bash "$(dirname "$0")/serve.sh"
