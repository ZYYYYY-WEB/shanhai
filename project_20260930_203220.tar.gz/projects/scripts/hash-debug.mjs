import { chromium } from 'playwright-core';

const CHROME = '/root/.cache/ms-playwright/chromium-1161/chrome-linux/chrome';
const browser = await chromium.launch({ executablePath: CHROME, args: ['--no-sandbox'] });
const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });

page.on('console', (m) => console.log('PAGE:', m.text()));

await page.goto('http://localhost:5000/#5', { waitUntil: 'networkidle' });
await page.waitForTimeout(2000);
const info = await page.evaluate(() => {
  const track = document.querySelector('section')?.parentElement;
  return {
    hash: window.location.hash,
    transform: track ? getComputedStyle(track).transform : null,
    sec0Rect: document.querySelectorAll('section')[0].getBoundingClientRect().left,
    sec5Rect: document.querySelectorAll('section')[5].getBoundingClientRect().left,
  };
});
console.log('RESULT', JSON.stringify(info, null, 2));
await browser.close();
