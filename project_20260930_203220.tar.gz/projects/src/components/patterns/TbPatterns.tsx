import type { PatternDef } from './types';

const GOLD_LINE = {
  fill: 'none',
  stroke: 'var(--l)',
  strokeLinejoin: 'round' as const,
  strokeLinecap: 'round' as const,
};

/* ================= 吉祥结（盘长） ================= */

function KnotL1() {
  return (
    <g>
      <rect x={20} y={20} width={60} height={60} rx={5} fill="none" stroke="var(--l)" strokeWidth={8} />
      <rect x={32} y={32} width={36} height={36} rx={3} fill="none" stroke="var(--l)" strokeWidth={7} />
    </g>
  );
}

function KnotL2() {
  return (
    <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={7}>
      <path d="M20 38 H8 V62 H20" />
      <path d="M80 38 H92 V62 H80" />
      <path d="M38 20 V8 H62 V20" />
      <path d="M38 80 V92 H62 V80" />
    </g>
  );
}

function KnotL3() {
  return (
    <g fill="var(--b)">
      <rect x={30} y={17} width={9} height={7} transform="rotate(45 34 20)" />
      <rect x={61} y={17} width={9} height={7} transform="rotate(45 65 20)" />
      <rect x={30} y={76} width={9} height={7} transform="rotate(45 34 80)" />
      <rect x={61} y={76} width={9} height={7} transform="rotate(45 65 80)" />
      <circle cx={50} cy={50} r={4.5} fill="var(--a)" />
    </g>
  );
}

/* ================= 莲花 ================= */

function LotusL1() {
  return (
    <g>
      <path
        d="M50 12 C46 30 34 40 22 44 C34 50 44 60 50 78 C56 60 66 50 78 44 C66 40 54 30 50 12 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3}
        strokeLinejoin="round"
      />
    </g>
  );
}

function LotusL2() {
  return (
    <g>
      <path d="M50 26 C40 40 28 46 16 47 C30 54 42 64 50 78 C58 64 70 54 84 47 C72 46 60 40 50 26 Z" fill="var(--ink)" opacity={0.9} />
    </g>
  );
}

function LotusL3() {
  return (
    <g>
      <path d="M14 84 H86 L78 92 H22 Z" fill="var(--b)" stroke="var(--l)" strokeWidth={2.5} strokeLinejoin="round" />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2.4}>
        <path d="M50 24 V74 M30 48 Q38 54 46 66 M70 48 Q62 54 54 66" />
      </g>
    </g>
  );
}

/* ================= 金鱼（双鱼） ================= */

function FishL1() {
  return (
    <g>
      <path
        d="M10 42 C22 30 38 30 48 42 C38 54 22 54 10 42 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3}
        strokeLinejoin="round"
      />
      <path
        d="M90 42 C78 30 62 30 52 42 C62 54 78 54 90 42 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3}
        strokeLinejoin="round"
      />
      <path d="M10 42 L4 32 V52 Z M90 42 L96 32 V52 Z" fill="var(--b)" stroke="var(--l)" strokeWidth={2.5} strokeLinejoin="round" />
    </g>
  );
}

function FishL2() {
  return (
    <g fill="var(--ink)">
      <path d="M20 42 Q30 37 40 42 Q30 47 20 42 Z" />
      <path d="M80 42 Q70 37 60 42 Q70 47 80 42 Z" />
    </g>
  );
}

function FishL3() {
  return (
    <g>
      <circle cx={42} cy={39} r={2.8} fill="var(--l)" />
      <circle cx={58} cy={39} r={2.8} fill="var(--l)" />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2.2}>
        <path d="M24 52 Q30 57 36 52 M76 52 Q70 57 64 52" />
        <path d="M30 64 Q50 74 70 64" />
      </g>
    </g>
  );
}

/* ================= 金轮（法轮） ================= */

function WheelL1() {
  return (
    <g>
      <circle cx={50} cy={50} r={38} fill="var(--b)" stroke="var(--l)" strokeWidth={3.5} />
      <circle cx={50} cy={50} r={31} fill="none" stroke="var(--l)" strokeWidth={2.5} />
    </g>
  );
}

function WheelL2() {
  const spokes = [0, 45, 90, 135, 180, 225, 270, 315];
  return (
    <g stroke="var(--l)" strokeWidth={3.4}>
      {spokes.map((a) => {
        const rad = (a * Math.PI) / 180;
        return (
          <line
            key={a}
            x1={50 + 12 * Math.cos(rad)}
            y1={50 + 12 * Math.sin(rad)}
            x2={50 + 29 * Math.cos(rad)}
            y2={50 + 29 * Math.sin(rad)}
          />
        );
      })}
    </g>
  );
}

function WheelL3() {
  return (
    <g>
      <circle cx={50} cy={50} r={11} fill="var(--a)" stroke="var(--l)" strokeWidth={2.5} />
      <circle cx={50} cy={50} r={4} fill="var(--l)" />
      {[0, 90, 180, 270].map((a) => {
        const rad = (a * Math.PI) / 180;
        return (
          <circle
            key={a}
            cx={50 + 31 * Math.cos(rad)}
            cy={50 + 31 * Math.sin(rad)}
            r={3}
            fill="var(--a)"
            stroke="var(--l)"
            strokeWidth={1.5}
          />
        );
      })}
    </g>
  );
}

/* ================= 宝伞 ================= */

function ParasolL1() {
  return (
    <g>
      <path
        d="M14 52 Q50 8 86 52 Q76 48 68 54 Q60 48 50 54 Q40 48 32 54 Q24 48 14 52 Z"
        fill="var(--b)"
        stroke="var(--l)"
        strokeWidth={3}
        strokeLinejoin="round"
      />
    </g>
  );
}

function ParasolL2() {
  return (
    <g>
      <line x1={50} y1={14} x2={50} y2={8} stroke="var(--l)" strokeWidth={3.5} />
      <circle cx={50} cy={6} r={4} fill="var(--a)" stroke="var(--l)" strokeWidth={2} />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2.2}>
        <path d="M26 52 Q27 66 25 76 M50 54 V80 M74 52 Q73 66 75 76" />
      </g>
    </g>
  );
}

function ParasolL3() {
  return (
    <g>
      <rect x={22} y={78} width={7} height={9} rx={2} fill="var(--a)" />
      <rect x={46.5} y={82} width={7} height={9} rx={2} fill="var(--a)" />
      <rect x={71} y={78} width={7} height={9} rx={2} fill="var(--a)" />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2}>
        <path d="M50 18 Q38 30 24 48 M50 18 Q62 30 76 48 M38 24 Q34 38 32 50 M62 24 Q66 38 68 50" />
      </g>
    </g>
  );
}

/* ================= 白海螺 ================= */

function ConchL1() {
  return (
    <path
      d="M22 80 C8 64 14 38 38 28 C66 16 88 34 82 56 C78 72 62 78 50 72 C42 68 42 58 50 55 C57 52 64 56 64 62"
      fill="var(--a)"
      stroke="var(--l)"
      strokeWidth={3.5}
      strokeLinejoin="round"
    />
  );
}

function ConchL2() {
  return (
    <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={3}>
      <path d="M34 70 C26 58 30 44 44 38 C58 32 70 40 70 52" />
      <path d="M46 62 C42 56 45 49 52 47 C59 45 63 50 61 55" />
    </g>
  );
}

function ConchL3() {
  return (
    <g>
      <path d="M62 62 L74 78 L66 78 L60 70 Z" fill="var(--b)" stroke="var(--l)" strokeWidth={2.2} strokeLinejoin="round" />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2}>
        <path d="M28 76 L20 86 M36 80 L30 90" />
      </g>
    </g>
  );
}

/* ================= 宝瓶 ================= */

function VaseL1() {
  return (
    <g>
      <path
        d="M38 20 H62 V30 C62 34 66 37 70 40 C80 48 80 66 70 75 C62 82 38 82 30 75 C20 66 20 48 30 40 C34 37 38 34 38 30 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3.5}
        strokeLinejoin="round"
      />
    </g>
  );
}

function VaseL2() {
  return (
    <g>
      <rect x={36} y={14} width={28} height={8} rx={3} fill="var(--b)" stroke="var(--l)" strokeWidth={2.2} />
      <path d="M32 56 Q50 66 68 56 V70 Q50 78 32 70 Z" fill="var(--ink)" opacity={0.85} />
    </g>
  );
}

function VaseL3() {
  return (
    <g>
      <circle cx={50} cy={44} r={5} fill="var(--b)" />
      <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2.2}>
        <path d="M30 48 Q50 56 70 48 M34 74 Q50 80 66 74" />
      </g>
    </g>
  );
}

/* ================= 胜利幢 ================= */

function BannerL1() {
  return (
    <g>
      <rect x={42} y={8} width={16} height={10} rx={2} fill="var(--b)" stroke="var(--l)" strokeWidth={2.5} />
      <path
        d="M30 22 H70 L72 74 Q50 82 28 74 Z"
        fill="var(--b)"
        stroke="var(--l)"
        strokeWidth={3}
        strokeLinejoin="round"
      />
    </g>
  );
}

function BannerL2() {
  return (
    <g {...GOLD_LINE} stroke="var(--l)" strokeWidth={2.4}>
      <path d="M36 34 H64 M35 46 H65 M34 58 H66" />
      <path d="M50 22 V72" />
    </g>
  );
}

function BannerL3() {
  return (
    <g>
      <path d="M28 74 L24 84 L32 78 M72 74 L76 84 L68 78 M50 80 L50 90 M39 77 L36 87 M61 77 L64 87" fill="var(--a)" stroke="var(--l)" strokeWidth={2} strokeLinejoin="round" />
    </g>
  );
}

/* ================= 数据注册 ================= */

export const TB_PATTERNS: PatternDef[] = [
  {
    id: 'tb-knot',
    name: '吉祥结',
    pinyin: 'BAO JIE',
    ethnic: 'tb',
    meaning: '永恒不绝',
    summary:
      '吉祥结（盘长）象征智慧与慈悲无始无终、永恒不绝，连绵的线条交织回绕，喻示众生心心相系、吉祥绵长，是八宝中最具代表性的符号。',
    layers: [
      { id: 'l1', name: '外框回线层', desc: '大小相套的方形回线，奠定盘长的回旋骨架。', node: <KnotL1 /> },
      { id: 'l2', name: '四出延线层', desc: '向四方延伸的出头线，象征吉祥延及四面八方。', node: <KnotL2 /> },
      { id: 'l3', name: '编织交点层', desc: '交叠压织的节点与中心宝点，表现编结的穿插秩序。', node: <KnotL3 /> },
    ],
  },
  {
    id: 'tb-lotus',
    name: '莲花',
    pinyin: 'BAO LIAN',
    ethnic: 'tb',
    meaning: '清净无染',
    summary:
      '莲花出淤泥而不染，象征清净、圣洁与觉悟的本性。莲瓣层层绽放，是唐卡与佛座上最常见的吉祥符号，寓意超凡脱俗。',
    layers: [
      { id: 'l1', name: '外层花瓣层', desc: '左右舒展的外层莲瓣，轮廓饱满对称。', node: <LotusL1 /> },
      { id: 'l2', name: '内层花瓣层', desc: '深色内瓣层层内收，表现花瓣叠压的层次。', node: <LotusL2 /> },
      { id: 'l3', name: '莲座脉纹层', desc: '下方莲座托底，瓣脉勾线收束整体。', node: <LotusL3 /> },
    ],
  },
  {
    id: 'tb-fish',
    name: '金鱼',
    pinyin: 'BAO YU',
    ethnic: 'tb',
    meaning: '自由喜乐',
    summary:
      '一对金鱼以鱼鳍与双眼相对，象征自在、活泼与复苏，喻示超越世间苦难、获得自由喜乐的生命状态，也寓意富足有余。',
    layers: [
      { id: 'l1', name: '鱼身轮廓层', desc: '左右相对的双鱼身形与叉尾，取对称构图。', node: <FishL1 /> },
      { id: 'l2', name: '鱼鳞色块层', desc: '身上弧形鳞块以深色平涂，表现鱼身质感。', node: <FishL2 /> },
      { id: 'l3', name: '眼鳍水纹层', desc: '点睛、鳃线与下方水波纹，象征自在游弋。', node: <FishL3 /> },
    ],
  },
  {
    id: 'tb-wheel',
    name: '金轮',
    pinyin: 'FA LUN',
    ethnic: 'tb',
    meaning: '正法常转',
    summary:
      '金轮（法轮）圆辐具足，象征佛法如车轮辗转、永不停息，亦含摧破烦恼、圆满无缺之意，八辐对应八正道。',
    layers: [
      { id: 'l1', name: '双轮圈层', desc: '内外两道轮圈，定出法轮的圆形秩序。', node: <WheelL1 /> },
      { id: 'l2', name: '八辐条层', desc: '八根辐条从轴心放射，对应八正道。', node: <WheelL2 /> },
      { id: 'l3', name: '轮毂宝饰层', desc: '中心轮毂与外圈宝珠，象征轴心不动。', node: <WheelL3 /> },
    ],
  },
  {
    id: 'tb-parasol',
    name: '宝伞',
    pinyin: 'BAO SAN',
    ethnic: 'tb',
    meaning: '庇护众生',
    summary:
      '宝伞张盖于上，象征遮蔽障热、庇护众生，伞盖垂帷代表慈悲护佑，顶宝象征觉悟的尊贵。',
    layers: [
      { id: 'l1', name: '伞盖层', desc: '弧形伞盖以波浪收边，表现张盖之势。', node: <ParasolL1 /> },
      { id: 'l2', name: '顶宝垂帷层', desc: '顶饰宝瓶、垂帷与骨架长线。', node: <ParasolL2 /> },
      { id: 'l3', name: '帷坠骨肋层', desc: '帷幔末端坠饰与伞骨肋线，刻画细部。', node: <ParasolL3 /> },
    ],
  },
  {
    id: 'tb-conch',
    name: '白海螺',
    pinyin: 'BAO LUO',
    ethnic: 'tb',
    meaning: '法音远播',
    summary:
      '右旋白海螺声音悠远，象征佛法传播四方、法音警醒世人，螺身回旋的螺纹喻示法音连绵。',
    layers: [
      { id: 'l1', name: '螺体外廓层', desc: '圆旋的螺体外轮廓，右旋开口。', node: <ConchL1 /> },
      { id: 'l2', name: '螺旋纹层', desc: '层层内收的螺纹环线，表现旋绕结构。', node: <ConchL2 /> },
      { id: 'l3', name: '螺唇水道层', desc: '螺唇出水口与水浪线，象征法音流布。', node: <ConchL3 /> },
    ],
  },
  {
    id: 'tb-vase',
    name: '宝瓶',
    pinyin: 'BAO PING',
    ethnic: 'tb',
    meaning: '福智圆满',
    summary:
      '宝瓶敛口圆腹，内盛甘露与珍宝，象征福智圆满、清净无漏，瓶中取之不尽的宝物寓意吉祥与财富的圆满。',
    layers: [
      { id: 'l1', name: '瓶腹轮廓层', desc: '敛口、鼓腹、收底的瓶身外轮廓。', node: <VaseL1 /> },
      { id: 'l2', name: '莲瓣宝盖层', desc: '瓶口宝冠与腹身莲瓣色块。', node: <VaseL2 /> },
      { id: 'l3', name: '宝饰弦纹层', desc: '腹心宝珠与上下弦纹勾线。', node: <VaseL3 /> },
    ],
  },
  {
    id: 'tb-banner',
    name: '胜利幢',
    pinyin: 'BAO ZHUANG',
    ethnic: 'tb',
    meaning: '战胜磨难',
    summary:
      '胜利幢为圆柱形战旗，象征战胜一切烦恼与障碍、佛法胜利，幢身垂幔飘扬，寓意克服磨难、赢得圆满。',
    layers: [
      { id: 'l1', name: '幢顶幢身层', desc: '幢顶宝帽与圆柱形幢身主体。', node: <BannerL1 /> },
      { id: 'l2', name: '幢幔横纹层', desc: '幢身水平幔纹与中轴竖线。', node: <BannerL2 /> },
      { id: 'l3', name: '幢坠飘带层', desc: '幢底飘坠与流苏，表现迎风之势。', node: <BannerL3 /> },
    ],
  },
];
