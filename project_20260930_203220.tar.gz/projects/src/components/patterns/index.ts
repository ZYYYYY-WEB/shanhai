export { YI_PATTERNS } from './YiPatterns';
export { TB_PATTERNS } from './TbPatterns';
export { PatternView } from './PatternView';
export { stageVars, STAGE_LABEL } from './types';
export type { PatternDef, PatternLayer, Stage, Ethnic } from './types';

import { YI_PATTERNS } from './YiPatterns';
import { TB_PATTERNS } from './TbPatterns';
import type { PatternDef } from './types';

export const ALL_PATTERNS: PatternDef[] = [...YI_PATTERNS, ...TB_PATTERNS];

export function findPattern(id: string): PatternDef {
  const found = ALL_PATTERNS.find((p) => p.id === id);
  if (!found) {
    throw new Error(`Pattern not found: ${id}`);
  }
  return found;
}
