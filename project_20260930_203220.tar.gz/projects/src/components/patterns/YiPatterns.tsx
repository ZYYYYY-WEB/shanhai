import type { PatternDef } from './types';

const STROKE = {
  fill: 'none',
  stroke: 'var(--l)',
  strokeWidth: 3,
  strokeLinejoin: 'round' as const,
  strokeLinecap: 'round' as const,
};

/* ================= 虎头纹（分层） ================= */

function TigerL1() {
  return (
    <path
      d="M50 12 L68 34 L92 28 L86 58 L92 82 L72 94 L50 88 L28 94 L8 82 L14 58 L8 28 L32 34 Z"
      fill="var(--a)"
      stroke="var(--l)"
      strokeWidth={3.5}
      strokeLinejoin="round"
    />
  );
}

function TigerL2() {
  return (
    <g>
      <path d="M38 20 L50 14 L62 20 L58 34 L42 34 Z" fill="var(--b)" />
      <path d="M18 46 Q30 50 30 64 L20 72 Z" fill="var(--b)" />
      <path d="M82 46 Q70 50 70 64 L80 72 Z" fill="var(--b)" />
      <path d="M38 66 L62 66 L58 80 L50 84 L42 80 Z" fill="var(--b)" />
      <circle cx="50" cy="58" r="6" fill="var(--ink)" />
    </g>
  );
}

function TigerL3() {
  return (
    <g {...STROKE} strokeWidth={3}>
      <path d="M43 24 H57 M45 29 H55" />
      <path d="M28 50 Q36 44 44 50" />
      <path d="M72 50 Q64 44 56 50" />
      <path d="M30 82 L34 76 M40 86 L42 79 M60 86 L58 79 M70 82 L66 76" />
      <path d="M22 58 H30 M70 58 H78" />
    </g>
  );
}

/* ================= 火纹（分层） ================= */

function FireL1() {
  return (
    <path
      d="M50 8 C62 30 80 40 76 62 C73 80 50 92 50 92 C50 92 27 80 24 62 C20 40 38 30 50 8 Z"
      fill="var(--a)"
      stroke="var(--l)"
      strokeWidth={3.5}
      strokeLinejoin="round"
    />
  );
}

function FireL2() {
  return (
    <path
      d="M50 34 C58 48 66 54 63 66 C61 77 50 84 50 84 C50 84 39 77 37 66 C34 54 42 48 50 34 Z"
      fill="var(--b)"
    />
  );
}

function FireL3() {
  return (
    <g>
      <path d="M50 54 L55 64 L50 74 L45 64 Z" fill="var(--ink)" />
      <g {...STROKE} strokeWidth={3}>
        <path d="M30 70 L36 66 M70 70 L64 66 M28 52 L35 50 M72 52 L65 50" />
      </g>
    </g>
  );
}

/* ================= 牛角纹（分层） ================= */

function HornL1() {
  return (
    <g>
      <path
        d="M50 92 C50 70 46 52 32 40 C22 31 12 30 10 30 C12 44 20 56 32 62 C42 67 46 76 46 92 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3.5}
        strokeLinejoin="round"
      />
      <path
        d="M50 92 C50 70 54 52 68 40 C78 31 88 30 90 30 C88 44 80 56 68 62 C58 67 54 76 54 92 Z"
        fill="var(--a)"
        stroke="var(--l)"
        strokeWidth={3.5}
        strokeLinejoin="round"
      />
    </g>
  );
}

function HornL2() {
  return <path d="M44 92 Q50 74 56 92 Z" fill="var(--b)" />;
}

function HornL3() {
  return (
    <g {...STROKE} strokeWidth={2.6}>
      <path d="M18 37 C28 40 36 48 40 58" />
      <path d="M82 37 C72 40 64 48 60 58" />
      <path d="M34 78 H66 M30 86 H70" />
    </g>
  );
}

/* ================= 回纹（分层） ================= */

function MeanderL1() {
  return <rect x={4} y={14} width={92} height={72} fill="var(--b)" opacity={0.9} />;
}

function MeanderL2() {
  const cell = (x: number, key: string) => (
    <g key={key}>
      <rect x={x} y={22} width={20} height={56} fill="none" stroke="var(--l)" strokeWidth={4} />
      <rect x={x + 5} y={27} width={10} height={24} fill="none" stroke="var(--l)" strokeWidth={4} />
    </g>
  );
  return (
    <g>
      {cell(9, 'a')}
      {cell(39, 'b')}
      {cell(69, 'c')}
    </g>
  );
}

function MeanderL3() {
  return (
    <g>
      <rect x={11} y={56} width={9} height={9} fill="var(--a)" />
      <rect x={41} y={56} width={9} height={9} fill="var(--a)" />
      <rect x={71} y={56} width={9} height={9} fill="var(--a)" />
      <path d="M29 50 H39 M59 50 H69" stroke="var(--a)" strokeWidth={5} />
      <path d="M4 88 H96 M4 12 H96" stroke="var(--l)" strokeWidth={2.5} strokeDasharray="2 6" />
    </g>
  );
}

/* ================= 数据注册 ================= */

export const YI_PATTERNS: PatternDef[] = [
  {
    id: 'yi-tiger',
    name: '虎头纹',
    pinyin: 'HU WEN',
    ethnic: 'yi',
    meaning: '驱邪护佑',
    summary:
      '虎是彝族的原始图腾。彝人相信虎是万物之祖，虎头纹绘于餐具、酒器与护身物之上，象征驱邪镇宅、护佑族人，亦含虎佑丰收之意。',
    layers: [
      { id: 'l1', name: '轮廓层', desc: '双耳、颧颊与下颌的外轮廓，定出虎头正面对称格局。', node: <TigerL1 /> },
      { id: 'l2', name: '填充色块层', desc: '黑地之上以红黄平涂色块：额块、双颊与吻部，对应三色信仰。', node: <TigerL2 /> },
      { id: 'l3', name: '刻线纹饰层', desc: '额间「王」字、眉目弧线与回纹状刻齿，是漆器刻划的最后一道工序。', node: <TigerL3 /> },
    ],
  },
  {
    id: 'yi-fire',
    name: '火纹',
    pinyin: 'HUO WEN',
    ethnic: 'yi',
    meaning: '火与生命',
    summary:
      '火塘是山地家屋的中心。火纹以几何化的升腾火焰表现彝族对火的崇拜——火驱寒熟食、照亮黑夜，是生命延续与家族兴旺的象征。',
    layers: [
      { id: 'l1', name: '外焰层', desc: '尖角外焰轮廓，直线转折，表现火苗的升腾之势。', node: <FireL1 /> },
      { id: 'l2', name: '内焰色块层', desc: '黄色内焰嵌于红色外焰之中，红为火、黄为阳光。', node: <FireL2 /> },
      { id: 'l3', name: '焰心刻线层', desc: '菱形焰心与对称刻线，象征火塘生生不息。', node: <FireL3 /> },
    ],
  },
  {
    id: 'yi-horn',
    name: '牛角纹',
    pinyin: 'NIU JIAO WEN',
    ethnic: 'yi',
    meaning: '祈福丰收',
    summary:
      '牛是山地农耕与祭祀中的重器。对称内弯的牛角纹寄寓五谷丰登、六畜兴旺，常见于漆碗与酒壶腹部，是彝族漆器的经典母题。',
    layers: [
      { id: 'l1', name: '双角轮廓层', desc: '左右对称、向内环抱的弧线，取牛角内弯之势。', node: <HornL1 /> },
      { id: 'l2', name: '额心色块层', desc: '两角之间的黄色三角，象征火塘与家屋中心。', node: <HornL2 /> },
      { id: 'l3', name: '角节刻线层', desc: '角身上的分段弧线与水平刻线，表现角质纹理与漆器节奏。', node: <HornL3 /> },
    ],
  },
  {
    id: 'yi-meander',
    name: '回旋几何纹',
    pinyin: 'HUI WEN',
    ethnic: 'yi',
    meaning: '往复不绝',
    summary:
      '连续回旋的几何回纹（也称雷纹）由直线折返构成，节奏铿锵，象征山路回环、水流往复与生命繁衍绵延不绝，是漆器边饰的主体语言。',
    layers: [
      { id: 'l1', name: '条带基底层', desc: '黄色条带为底，是回纹连续铺展的漆器地色。', node: <MeanderL1 /> },
      { id: 'l2', name: '回折单元层', desc: '方框逐层回折的独立单元，等距排列成节奏。', node: <MeanderL2 /> },
      { id: 'l3', name: '勾连连缀层', desc: '红色短块勾连相邻单元，虚线收束上下边缘。', node: <MeanderL3 /> },
    ],
  },
];
