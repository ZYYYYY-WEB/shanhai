import type { CSSProperties, ReactNode } from 'react';

/** 演变阶段：0=古器物原图 1=手绘提取线稿 2=简化矢量版 */
export type Stage = 0 | 1 | 2;

export type Ethnic = 'yi' | 'tb';

/** 纹样分层（用于拆解交互） */
export interface PatternLayer {
  id: string;
  name: string;
  desc: string;
  node: ReactNode;
}

export interface PatternDef {
  id: string;
  name: string;
  pinyin: string;
  ethnic: Ethnic;
  meaning: string;
  summary: string;
  layers: PatternLayer[];
}

type VarMap = Record<string, string>;

/** 根据民族 + 演变阶段，注入语义化色彩变量：--a 主色 / --b 辅色 / --l 勾线 / --bg 底色 */
export function stageVars(ethnic: Ethnic, stage: Stage): CSSProperties {
  const rough = stage === 0;
  const sketch = stage === 1;
  let vars: VarMap;
  if (sketch) {
    vars = {
      '--a': 'rgba(185,199,198,0.18)',
      '--b': 'rgba(185,199,198,0.10)',
      '--l': '#B9C7C6',
      '--ink': '#B9C7C6',
      '--bg': 'none',
    };
  } else if (rough) {
    vars =
      ethnic === 'yi'
        ? {
            '--a': '#8F2A22',
            '--b': '#B98A32',
            '--l': '#D8A94A',
            '--ink': '#170F09',
            '--bg': '#221810',
          }
        : {
            '--a': '#C9973F',
            '--b': '#B03A2E',
            '--l': '#E0B55E',
            '--ink': '#2A0F0D',
            '--bg': '#431714',
          };
  } else {
    vars =
      ethnic === 'yi'
        ? {
            '--a': '#C0392B',
            '--b': '#E8B84B',
            '--l': '#F2D078',
            '--ink': '#160F0A',
            '--bg': 'none',
          }
        : {
            '--a': '#E8B84B',
            '--b': '#9E2B25',
            '--l': '#F2D078',
            '--ink': '#731C19',
            '--bg': 'none',
          };
  }
  return vars as CSSProperties;
}

export const STAGE_LABEL: Record<Stage, string> = {
  0: '古器原图',
  1: '线稿提取',
  2: '矢量简化',
} as const;
