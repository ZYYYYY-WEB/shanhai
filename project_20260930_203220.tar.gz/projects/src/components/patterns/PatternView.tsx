import type { CSSProperties } from 'react';
import type { PatternDef, Stage } from './types';
import { stageVars } from './types';

interface PatternViewProps {
  pattern: PatternDef;
  stage: Stage;
  className?: string;
  style?: CSSProperties;
  title?: string;
}

/** 完整渲染一个纹样（所有层叠加） */
export function PatternView({ pattern, stage, className, style, title }: PatternViewProps) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={className}
      style={{ ...stageVars(pattern.ethnic, stage), overflow: 'visible', ...style }}
      role="img"
      aria-label={title ?? pattern.name}
    >
      {stage === 0 && (
        <rect x={2} y={2} width={96} height={96} rx={4} fill="var(--bg)" />
      )}
      {pattern.layers.map((layer) => (
        <g key={layer.id}>{layer.node}</g>
      ))}
    </svg>
  );
}
