interface NavDotsProps {
  count: number;
  current: number;
  labels: string[];
  onJump: (index: number) => void;
}

export function NavDots({ count, current, labels, onJump }: NavDotsProps) {
  return (
    <nav className="fixed bottom-6 left-1/2 z-[70] flex -translate-x-1/2 items-center gap-3 rounded-full border border-[rgba(185,199,198,0.18)] bg-black/40 px-5 py-2.5 backdrop-blur-md">
      {Array.from({ length: count }, (_, i) => {
        const active = i === current;
        return (
          <button
            key={i}
            type="button"
            onClick={() => onJump(i)}
            className="group relative flex items-center"
            aria-label={`前往 ${labels[i]}`}
            aria-current={active ? 'true' : undefined}
          >
            <span
              className={`block rounded-full transition-all duration-500 ease-ritual ${
                active
                  ? 'h-2.5 w-8 bg-imperial'
                  : 'h-2.5 w-2.5 bg-celadon/40 group-hover:bg-celadon'
              }`}
            />
            <span className="pointer-events-none absolute -top-9 left-1/2 -translate-x-1/2 whitespace-nowrap rounded-sm bg-lacquer-soft px-2 py-1 text-[11px] tracking-widest text-celadon opacity-0 transition-opacity duration-300 group-hover:opacity-100">
              {labels[i]}
            </span>
          </button>
        );
      })}
    </nav>
  );
}
