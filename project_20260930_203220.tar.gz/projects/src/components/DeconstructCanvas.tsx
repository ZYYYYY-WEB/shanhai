import type { CSSProperties } from 'react';
import type { PatternDef, Stage } from './patterns';
import { stageVars } from './patterns';

interface DeconstructCanvasProps {
  pattern: PatternDef;
  stage: Stage;
  expanded: boolean;
  activeLayerId: string | null;
  onToggleExpand: () => void;
  onSelectLayer: (layerId: string) => void;
  label: string;
}

/** 各层拆解散开方向（SVG 用户单位） */
const SCATTER: Array<{ dx: number; dy: number; tag: { x: number; y: number } }> = [
  { dx: -17, dy: -13, tag: { x: 30, y: 4 } },
  { dx: 17, dy: -3, tag: { x: 70, y: 12 } },
  { dx: 0, dy: 17, tag: { x: 50, y: 100 } },
];

export function DeconstructCanvas({
  pattern,
  stage,
  expanded,
  activeLayerId,
  onToggleExpand,
  onSelectLayer,
  label,
}: DeconstructCanvasProps) {
  return (
    <div className="relative flex h-full min-h-0 w-full flex-col">
      <p className="mb-1.5 flex items-center justify-between text-[10px] tracking-[0.3em] text-celadon/55">
        <span>{label}</span>
        <span className="text-celadon/40">点击纹样局部进行拆解</span>
      </p>
      <button
        type="button"
        onClick={onToggleExpand}
        className="gold-frame relative flex min-h-0 flex-1 items-center justify-center overflow-hidden rounded-sm bg-[#0F0A07]"
        aria-label={expanded ? '重组纹样' : '拆解纹样'}
        data-active-layer={activeLayerId ?? ''}
      >
        {/* 画布网格 */}
        <div
          className="pointer-events-none absolute inset-0 opacity-40"
          style={{
            backgroundImage:
              'linear-gradient(rgba(185,199,198,0.06) 1px, transparent 1px), linear-gradient(90deg, rgba(185,199,198,0.06) 1px, transparent 1px)',
            backgroundSize: '32px 32px',
          }}
        />
        <svg
          viewBox="0 0 100 100"
          className="h-[min(100%,42vh)] w-auto"
          style={{ ...stageVars(pattern.ethnic, stage), overflow: 'visible' } as CSSProperties}
        >
          {stage === 0 && <rect x={2} y={2} width={96} height={96} rx={4} fill="var(--bg)" />}
          {pattern.layers.map((layer, i) => {
            const pos = SCATTER[i];
            const dimmed = expanded && activeLayerId !== null && activeLayerId !== layer.id;
            return (
              <g
                key={layer.id}
                role="button"
                aria-label={layer.name}
                onClick={(e) => {
                  e.stopPropagation();
                  if (!expanded) {
                    onToggleExpand();
                  }
                  onSelectLayer(layer.id);
                }}
                className="cursor-pointer"
                style={{
                  transform: expanded ? `translate(${pos.dx}px, ${pos.dy}px)` : 'translate(0px, 0px)',
                  transition: 'transform 750ms cubic-bezier(0.22,1,0.36,1), opacity 400ms ease',
                  opacity: dimmed ? 0.25 : 1,
                }}
              >
                {layer.node}
                {/* 拆解后的引线（内部坐标需扣除散开位移；标签为下方 HTML 覆盖层） */}
                <line
                  opacity={expanded ? 1 : 0}
                  x1={50}
                  y1={50}
                  x2={pos.tag.x - pos.dx}
                  y2={pos.tag.y - pos.dy}
                  stroke="var(--l)"
                  strokeWidth={0.5}
                  strokeDasharray="1.5 1.5"
                  style={{ transition: 'opacity 500ms ease 300ms' }}
                />
              </g>
            );
          })}
        </svg>

        {/* 拆解后的层名标签（HTML 覆盖层：自适应宽度、允许换行，避免超出边框） */}
        <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
          <div className="relative h-[min(100%,42vh)] w-[min(100%,42vh)]">
            {pattern.layers.map((layer, i) => {
              const pos = SCATTER[i];
              const placeBelow = pos.tag.y < 22;
              return (
                <span
                  key={layer.id}
                  className="absolute max-w-[42%] rounded-[3px] border border-[var(--l)] bg-[rgba(13,9,6,0.92)] px-1.5 py-[3px] text-center text-[9px] leading-tight tracking-wide text-[var(--l)]"
                  style={{
                    left: `${pos.tag.x}%`,
                    top: placeBelow ? `${pos.tag.y + 4}%` : `${pos.tag.y - 4}%`,
                    transform: `translateX(-50%)${placeBelow ? '' : ' translateY(-100%)'}`,
                    opacity: expanded ? 1 : 0,
                    transition: 'opacity 500ms ease',
                    transitionDelay: expanded ? '300ms' : '0ms',
                  }}
                >
                  {layer.name}
                </span>
              );
            })}
          </div>
        </div>

        {/* 拆解/重组角标按钮 */}
        <span
          className={`absolute bottom-3 right-3 rounded-sm border px-3 py-1 text-[10px] tracking-widest transition-colors ${
            expanded
              ? 'border-imperial/70 text-imperial'
              : 'border-celadon/30 text-celadon/70 hover:border-imperial/60 hover:text-imperial'
          }`}
        >
          {expanded ? '↩ 重组纹样' : '✦ 拆解纹样'}
        </span>
      </button>
    </div>
  );
}
