import { useRef, useState, type DragEvent, type PointerEvent } from 'react';
import html2canvas from 'html2canvas';
import { PageHeader } from '../PageHeader';
import { FRAGMENTS, FragmentSvg } from './FragmentArt';
import type { FragColors, FragmentDef } from './FragmentArt';

interface WorkshopPageProps {
  active: boolean;
}

interface BoardItem {
  uid: number;
  fragmentId: string;
  x: number;
  y: number;
  scale: number;
  rotate: number;
}

const PALETTES: Array<{ id: string; name: string; boardBg: string; colors: FragColors; swatch: string[] }> = [
  {
    id: 'lacquer',
    name: '漆彩 · 黑红黄',
    boardBg: '#1A120C',
    colors: { c1: '#C0392B', c2: '#E8B84B', cl: '#F2D078' },
    swatch: ['#15100C', '#C0392B', '#E8B84B'],
  },
  {
    id: 'tibetan',
    name: '藏彩 · 红金',
    boardBg: '#2A100E',
    colors: { c1: '#E8B84B', c2: '#9E2B25', cl: '#F2D078' },
    swatch: ['#731C19', '#E8B84B', '#F2D078'],
  },
  {
    id: 'ink',
    name: '金墨 · 黑金',
    boardBg: '#15100C',
    colors: { c1: '#C8923A', c2: '#E8B84B', cl: '#F2D078' },
    swatch: ['#15100C', '#C8923A', '#F2D078'],
  },
];

export function WorkshopPage({ active }: WorkshopPageProps) {
  const [items, setItems] = useState<BoardItem[]>([]);
  const [selectedUid, setSelectedUid] = useState<number | null>(null);
  const [paletteId, setPaletteId] = useState('lacquer');
  const [saving, setSaving] = useState(false);
  const boardRef = useRef<HTMLDivElement>(null);
  const dragStateRef = useRef<{ uid: number; startX: number; startY: number; originX: number; originY: number } | null>(null);
  const uidRef = useRef(0);

  const palette = PALETTES.find((p) => p.id === paletteId) ?? PALETTES[0];
  const selectedItem = items.find((i) => i.uid === selectedUid) ?? null;

  const addFragment = (fragment: FragmentDef, clientX?: number, clientY?: number) => {
    const board = boardRef.current;
    uidRef.current += 1;
    const uid = uidRef.current;
    let x = 50;
    let y = 50;
    if (board && clientX !== undefined && clientY !== undefined) {
      const rect = board.getBoundingClientRect();
      x = ((clientX - rect.left) / rect.width) * 100;
      y = ((clientY - rect.top) / rect.height) * 100;
    }
    setItems((prev) => [
      ...prev,
      { uid, fragmentId: fragment.id, x: Math.max(4, Math.min(92, x - 5)), y: Math.max(4, Math.min(92, y - 5)), scale: 0.85, rotate: 0 },
    ]);
    setSelectedUid(uid);
  };

  const onDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const onDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const fragmentId = e.dataTransfer.getData('text/fragment-id');
    const fragment = FRAGMENTS.find((f) => f.id === fragmentId);
    if (fragment) addFragment(fragment, e.clientX, e.clientY);
  };

  const startItemDrag = (e: PointerEvent<HTMLDivElement>, item: BoardItem) => {
    e.preventDefault();
    setSelectedUid(item.uid);
    dragStateRef.current = { uid: item.uid, startX: e.clientX, startY: e.clientY, originX: item.x, originY: item.y };
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const onItemPointerMove = (e: PointerEvent<HTMLDivElement>) => {
    const state = dragStateRef.current;
    const board = boardRef.current;
    if (!state || !board || state.uid !== selectedUid) return;
    const rect = board.getBoundingClientRect();
    const dxPct = ((e.clientX - state.startX) / rect.width) * 100;
    const dyPct = ((e.clientY - state.startY) / rect.height) * 100;
    setItems((prev) =>
      prev.map((it) =>
        it.uid === state.uid
          ? {
              ...it,
              x: Math.max(2, Math.min(92, state.originX + dxPct)),
              y: Math.max(2, Math.min(92, state.originY + dyPct)),
            }
          : it,
      ),
    );
  };

  const endItemDrag = () => {
    dragStateRef.current = null;
  };

  const updateSelected = (patch: Partial<BoardItem>) => {
    if (selectedUid === null) return;
    setItems((prev) => prev.map((it) => (it.uid === selectedUid ? { ...it, ...patch } : it)));
  };

  const removeSelected = () => {
    if (selectedUid === null) return;
    setItems((prev) => prev.filter((it) => it.uid !== selectedUid));
    setSelectedUid(null);
  };

  const saveImage = async () => {
    const board = boardRef.current;
    if (!board || items.length === 0) return;
    setSaving(true);
    try {
      const canvas = await html2canvas(board, {
        backgroundColor: palette.boardBg,
        scale: 2,
        useCORS: true,
      });
      const link = document.createElement('a');
      link.download = `山海纹叙-我的纹样-${Date.now()}.png`;
      link.href = canvas.toDataURL('image/png');
      link.click();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className={`flex h-full flex-col px-10 pb-16 pt-20 ${active ? 'anim-emerge-soft' : 'opacity-0'}`}>
      <PageHeader
        index="叁"
        title="再创作工坊"
        pinyin="RE-CREATION STUDIO"
        desc="拖拽提取的纹样碎片到画板，缩放、旋转、配色——重组属于你的当代民族纹样。"
      />

      <div className="mt-4 grid min-h-0 flex-1 grid-cols-[210px_1fr] gap-4">
        {/* 素材库 */}
        <div className="flex min-h-0 flex-col rounded-sm border hairline bg-black/25 p-3" data-no-slide>
          <p className="mb-2 text-[10px] tracking-[0.3em] text-celadon/60">矢量纹样碎片 · 拖入画板</p>
          <div className="thin-scroll grid flex-1 grid-cols-2 content-start gap-2 overflow-y-auto pr-1">
            {FRAGMENTS.map((fragment) => (
              <button
                key={fragment.id}
                type="button"
                draggable
                onDragStart={(e) => {
                  e.dataTransfer.setData('text/fragment-id', fragment.id);
                  e.dataTransfer.effectAllowed = 'copy';
                }}
                onDoubleClick={() => addFragment(fragment)}
                onClick={() => addFragment(fragment)}
                title="点击或拖入画板"
                className="group flex flex-col items-center rounded-sm border hairline bg-[#0F0A07] p-2 transition-all hover:-translate-y-0.5 hover:border-imperial/60"
              >
                <FragmentSvg fragment={fragment} colors={palette.colors} className="h-16 w-16" />
                <span className="mt-1 text-[10px] tracking-widest text-celadon/75 group-hover:text-imperial">{fragment.name}</span>
                <span className="text-[9px] text-celadon/45">{fragment.origin}</span>
              </button>
            ))}
          </div>
          {/* 配色切换 */}
          <div className="mt-3 border-t hairline pt-3">
            <p className="mb-2 text-[10px] tracking-[0.3em] text-celadon/60">配色方案</p>
            <div className="flex flex-col gap-1.5">
              {PALETTES.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setPaletteId(p.id)}
                  className={`flex items-center gap-2 rounded-sm border px-2 py-1.5 text-[10px] tracking-wider transition-all ${
                    paletteId === p.id ? 'border-imperial text-imperial-soft' : 'border-celadon/20 text-celadon/65 hover:border-imperial/50'
                  }`}
                >
                  <span className="flex">
                    {p.swatch.map((s) => (
                      <span key={s} className="h-3.5 w-3.5 rounded-full border border-black/50" style={{ backgroundColor: s }} />
                    ))}
                  </span>
                  {p.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* 画板 + 工具条 */}
        <div className="flex min-h-0 flex-col">
          <div
            ref={boardRef}
            onDragOver={onDragOver}
            onDrop={onDrop}
            onClick={() => setSelectedUid(null)}
            className="canvas-board relative min-h-0 flex-1 overflow-hidden rounded-sm gold-frame"
            style={{ backgroundColor: palette.boardBg }}
            data-no-slide
          >
            {items.length === 0 && (
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center gap-3 text-celadon/40">
                <svg width="52" height="52" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1">
                  <rect x="3" y="3" width="18" height="18" rx="2" />
                  <path d="M12 8 V16 M8 12 H16" />
                </svg>
                <p className="text-xs tracking-[0.35em]">将左侧碎片拖入此处</p>
              </div>
            )}
            {items.map((item) => {
              const fragment = FRAGMENTS.find((f) => f.id === item.fragmentId);
              if (!fragment) return null;
              const selected = item.uid === selectedUid;
              return (
                <div
                  key={item.uid}
                  role="button"
                  tabIndex={0}
                  onPointerDown={(e) => startItemDrag(e, item)}
                  onPointerMove={onItemPointerMove}
                  onPointerUp={endItemDrag}
                  onPointerCancel={endItemDrag}
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedUid(item.uid);
                  }}
                  className="absolute cursor-grab touch-none active:cursor-grabbing"
                  style={{
                    left: `${item.x}%`,
                    top: `${item.y}%`,
                    width: '12%',
                    transform: `translate(-50%, -50%) scale(${item.scale}) rotate(${item.rotate}deg)`,
                    outline: selected ? '1px dashed rgba(232,184,75,0.8)' : 'none',
                    outlineOffset: '4px',
                  }}
                >
                  <FragmentSvg fragment={fragment} colors={palette.colors} className="h-auto w-full" />
                </div>
              );
            })}
          </div>

          {/* 编辑工具条 */}
          <div className="mt-3 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-sm border hairline bg-black/30 px-4 py-2.5" data-no-slide>
            <span className="text-[10px] tracking-[0.3em] text-celadon/55">
              {selectedItem ? '编辑碎片' : '未选中碎片'}
            </span>
            <label className="flex items-center gap-2 text-[11px] text-celadon/75">
              缩放
              <input
                type="range"
                min={0.3}
                max={2.2}
                step={0.05}
                value={selectedItem?.scale ?? 0.85}
                disabled={!selectedItem}
                onChange={(e) => updateSelected({ scale: Number(e.target.value) })}
                className="ritual-range w-28 disabled:opacity-30"
              />
            </label>
            <label className="flex items-center gap-2 text-[11px] text-celadon/75">
              旋转
              <input
                type="range"
                min={0}
                max={360}
                step={5}
                value={selectedItem?.rotate ?? 0}
                disabled={!selectedItem}
                onChange={(e) => updateSelected({ rotate: Number(e.target.value) })}
                className="ritual-range w-28 disabled:opacity-30"
              />
            </label>
            <button
              type="button"
              onClick={() => updateSelected({ rotate: (selectedItem?.rotate ?? 0) - 45 })}
              disabled={!selectedItem}
              className="rounded-sm border border-celadon/25 px-2 py-1 text-[10px] tracking-widest text-celadon/70 hover:border-imperial/60 hover:text-imperial disabled:opacity-30"
            >
              ↺45°
            </button>
            <button
              type="button"
              onClick={removeSelected}
              disabled={!selectedItem}
              className="rounded-sm border border-celadon/25 px-2 py-1 text-[10px] tracking-widest text-celadon/70 hover:border-tibetan/70 hover:text-tibetan-bright disabled:opacity-30"
            >
              删除
            </button>
            <button
              type="button"
              onClick={() => setItems([])}
              disabled={items.length === 0}
              className="rounded-sm border border-celadon/25 px-2 py-1 text-[10px] tracking-widest text-celadon/70 hover:border-tibetan/70 disabled:opacity-30"
            >
              清空画板
            </button>
            <button
              type="button"
              onClick={saveImage}
              disabled={items.length === 0 || saving}
              className="ml-auto rounded-sm border border-imperial/60 bg-tibetan-deep px-5 py-1.5 text-[11px] tracking-widest text-imperial-soft transition hover:bg-tibetan disabled:opacity-40"
            >
              {saving ? '正在导出…' : '⬇ 一键保存图片'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
