import { useState } from 'react';
import { PageHeader } from '../PageHeader';
import { DeconstructCanvas } from '../DeconstructCanvas';
import { YI_PATTERNS, TB_PATTERNS, STAGE_LABEL } from '../patterns';
import type { PatternDef, Stage } from '../patterns';

interface LabPageProps {
  active: boolean;
  stageHint: number;
}

type ViewMode = 'yi' | 'tb' | 'split';

function PatternChip({
  pattern,
  selected,
  onPick,
}: {
  pattern: PatternDef;
  selected: boolean;
  onPick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onPick}
      className={`rounded-sm border px-2 py-1.5 text-left text-[11px] tracking-wider transition-all duration-300 ${
        selected
          ? 'border-imperial bg-imperial/15 text-imperial-soft'
          : 'border-celadon/20 text-celadon/70 hover:border-imperial/50 hover:text-celadon'
      }`}
    >
      {pattern.name}
      <span className="ml-1 text-[9px] opacity-60">{pattern.meaning}</span>
    </button>
  );
}

export function LabPage({ active }: LabPageProps) {
  const [mode, setMode] = useState<ViewMode>('yi');
  const [yiId, setYiId] = useState('yi-tiger');
  const [tbId, setTbId] = useState('tb-knot');
  const [expandedL, setExpandedL] = useState(false);
  const [expandedR, setExpandedR] = useState(false);
  const [layerL, setLayerL] = useState<string | null>(null);
  const [layerR, setLayerR] = useState<string | null>(null);
  const [stage, setStage] = useState<Stage>(2);

  const yiPattern = YI_PATTERNS.find((p) => p.id === yiId) ?? YI_PATTERNS[0];
  const tbPattern = TB_PATTERNS.find((p) => p.id === tbId) ?? TB_PATTERNS[0];

  const activeLayerDefL = layerL ? yiPattern.layers.find((l) => l.id === layerL) : null;
  const activeLayerDefR = layerR ? tbPattern.layers.find((l) => l.id === layerR) : null;

  const switchMode = (next: ViewMode) => {
    setMode(next);
  };

  return (
    <div className={`flex h-full flex-col px-10 pb-16 pt-20 ${active ? 'anim-emerge-soft' : 'opacity-0'}`}>
      <PageHeader
        index="贰"
        title="纹样对比解构实验室"
        pinyin="DECONSTRUCTION LAB"
        desc="主动点击、亲手拆解：看纹样由哪些图层构成，在三千年的器形上如何演变。"
      />

      {/* 控制行：视图模式 + 时间轴 */}
      <div className="mt-4 flex flex-wrap items-center gap-x-8 gap-y-2">
        <div className="flex items-center gap-2">
          <span className="text-[10px] tracking-[0.3em] text-celadon/55">视图模式</span>
          {(
            [
              { key: 'yi', label: '彝族漆器' },
              { key: 'tb', label: '藏族八宝' },
              { key: 'split', label: '双视图对比' },
            ] as const
          ).map((v) => (
            <button
              key={v.key}
              type="button"
              onClick={() => switchMode(v.key)}
              className={`rounded-sm border px-3 py-1 text-[11px] tracking-widest transition-all ${
                mode === v.key
                  ? 'border-imperial bg-tibetan-deep text-imperial-soft'
                  : 'border-celadon/20 text-celadon/65 hover:border-imperial/50'
              }`}
            >
              {v.label}
            </button>
          ))}
        </div>

        <div className="flex min-w-[280px] flex-1 items-center gap-3">
          <span className="text-[10px] tracking-[0.3em] text-celadon/55">演变时间轴</span>
          <input
            type="range"
            min={0}
            max={2}
            step={1}
            value={stage}
            onChange={(e) => setStage(Number(e.target.value) as Stage)}
            className="ritual-range w-44"
            aria-label="纹样演变时间轴"
          />
          <div className="flex gap-3 text-[10px] tracking-widest">
            {([0, 1, 2] as Stage[]).map((s) => (
              <span key={s} className={stage === s ? 'text-imperial' : 'text-celadon/40'}>
                {STAGE_LABEL[s]}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* 主体：纹样选择栏 + 画布 */}
      <div className="mt-4 grid min-h-0 flex-1 grid-cols-[150px_1fr] gap-4">
        {/* 选择栏 */}
        <div className="thin-scroll flex flex-col gap-4 overflow-y-auto rounded-sm border hairline bg-black/25 p-3" data-no-slide>
          {mode !== 'tb' && (
            <div>
              <p className="mb-2 text-[10px] tracking-[0.3em] text-tibetan-bright">彝族纹样</p>
              <div className="flex flex-col gap-1.5">
                {YI_PATTERNS.map((p) => (
                  <PatternChip
                    key={p.id}
                    pattern={p}
                    selected={yiId === p.id}
                    onPick={() => {
                      setYiId(p.id);
                      setExpandedL(false);
                      setLayerL(null);
                    }}
                  />
                ))}
              </div>
            </div>
          )}
          {mode !== 'yi' && (
            <div>
              <p className="mb-2 text-[10px] tracking-[0.3em] text-imperial-soft">藏族纹样</p>
              <div className="flex flex-col gap-1.5">
                {TB_PATTERNS.map((p) => (
                  <PatternChip
                    key={p.id}
                    pattern={p}
                    selected={tbId === p.id}
                    onPick={() => {
                      setTbId(p.id);
                      setExpandedR(false);
                      setLayerR(null);
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* 画布区 */}
        <div className="grid min-h-0 gap-4" style={{ gridTemplateColumns: mode === 'split' ? '1fr 1fr' : '1fr' }}>
          {mode !== 'tb' && (
            <div className="flex min-h-0 flex-col">
              <div className="min-h-0 flex-1">
                <DeconstructCanvas
                  pattern={yiPattern}
                  stage={stage}
                  expanded={expandedL}
                  activeLayerId={layerL}
                  onToggleExpand={() => {
                    setExpandedL((v) => !v);
                    setLayerL(null);
                  }}
                  onSelectLayer={setLayerL}
                  label={mode === 'split' ? `彝族漆器 · ${yiPattern.name}` : ''}
                />
              </div>
              {/* 解说区 */}
              <div className="mt-2 rounded-sm border hairline bg-black/25 px-3 py-2" data-no-slide>
                {activeLayerDefL && expandedL ? (
                  <p className="text-[11px] leading-5 text-celadon/80">
                    <span className="text-imperial">{activeLayerDefL.name}</span> · {activeLayerDefL.desc}
                  </p>
                ) : (
                  <p className="text-[11px] leading-5 text-celadon/65">
                    <span className="text-tibetan-bright">{yiPattern.name}</span>（{yiPattern.meaning}）：{yiPattern.summary}
                  </p>
                )}
              </div>
            </div>
          )}

          {mode !== 'yi' && (
            <div className="flex min-h-0 flex-col">
              <div className="min-h-0 flex-1">
                <DeconstructCanvas
                  pattern={tbPattern}
                  stage={stage}
                  expanded={expandedR}
                  activeLayerId={layerR}
                  onToggleExpand={() => {
                    setExpandedR((v) => !v);
                    setLayerR(null);
                  }}
                  onSelectLayer={setLayerR}
                  label={mode === 'split' ? `藏族八宝 · ${tbPattern.name}` : ''}
                />
              </div>
              <div className="mt-2 rounded-sm border hairline bg-black/25 px-3 py-2" data-no-slide>
                {activeLayerDefR && expandedR ? (
                  <p className="text-[11px] leading-5 text-celadon/80">
                    <span className="text-imperial">{activeLayerDefR.name}</span> · {activeLayerDefR.desc}
                  </p>
                ) : (
                  <p className="text-[11px] leading-5 text-celadon/65">
                    <span className="text-imperial-soft">{tbPattern.name}</span>（{tbPattern.meaning}）：{tbPattern.summary}
                  </p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
