import { useState, type ReactNode } from 'react';
import { PageHeader } from '../PageHeader';
import { Modal } from '../Modal';
import { PatternView, findPattern } from '../patterns';
import { YI_ARTIFACTS, TB_ARTIFACTS, type ArtifactDef } from './artifacts';

interface OriginPageProps {
  active: boolean;
}

const TRI_COLOR = [
  { color: '#15100C', ring: true, name: '黑', mean: '大地' },
  { color: '#C0392B', ring: false, name: '红', mean: '火与生命' },
  { color: '#E8B84B', ring: false, name: '黄', mean: '阳光' },
];

const EIGHT_TREASURES = [
  { name: '宝伞', mean: '庇护' },
  { name: '白海螺', mean: '法音远播' },
  { name: '宝瓶', mean: '福智圆满' },
  { name: '吉祥结', mean: '永恒' },
  { name: '金轮', mean: '正法常转' },
  { name: '金鱼', mean: '自由喜乐' },
  { name: '莲花', mean: '清净' },
  { name: '胜利幢', mean: '战胜磨难' },
];

function ArtifactCard({ artifact, onOpen }: { artifact: ArtifactDef; onOpen: (a: ArtifactDef) => void }) {
  return (
    <button
      type="button"
      onClick={() => onOpen(artifact)}
      className="group relative flex h-full flex-col items-center justify-end rounded-sm border hairline bg-black/30 p-2 transition-all duration-300 hover:-translate-y-1 hover:border-imperial/60 hover:bg-black/50"
    >
      <svg viewBox="0 0 100 100" className="h-full max-h-24 w-auto">
        {artifact.node}
      </svg>
      <span className="mt-1 text-[11px] tracking-widest text-celadon/80 group-hover:text-imperial">
        {artifact.name}
      </span>
      <span className="pointer-events-none absolute -top-11 left-1/2 z-20 w-32 -translate-x-1/2 rounded-sm bg-lacquer-soft px-2 py-1.5 text-center text-[10px] leading-relaxed text-celadon opacity-0 shadow-xl transition-opacity duration-300 group-hover:opacity-100">
        {artifact.note}
      </span>
    </button>
  );
}

function Column({
  side,
  children,
}: {
  side: 'yi' | 'tb';
  children: ReactNode;
}) {
  const border = side === 'yi' ? 'border-lacquer-line' : 'border-tibetan-deep/60';
  const bg = side === 'yi' ? 'bg-gradient-to-b from-[#1B130C] to-[#15100C]' : 'bg-gradient-to-b from-[#2A1210] to-[#15100C]';
  return (
    <div className={`relative flex h-full flex-col rounded-sm border ${border} ${bg} p-6`}>
      {children}
    </div>
  );
}

export function OriginPage({ active }: OriginPageProps) {
  const [opened, setOpened] = useState<ArtifactDef | null>(null);
  const pattern = opened ? findPattern(opened.patternId) : null;

  return (
    <div className={`flex h-full flex-col px-10 pb-16 pt-20 ${active ? 'anim-emerge-soft' : 'opacity-0'}`}>
      <PageHeader
        index="壹"
        title="文化溯源"
        pinyin="CULTURAL ORIGIN"
        desc="拆解之前，先溯其源：山地的生漆与火，雪域的金光与愿。"
      />

      <div className="mt-5 grid min-h-0 flex-1 grid-cols-2 gap-6">
        {/* 左：彝族漆器 */}
        <Column side="yi">
          <div className="flex items-center gap-3">
            <h3 className="font-cal text-2xl text-paper">彝族漆器文化</h3>
            <span className="rounded-full border border-tibetan/50 px-2 py-0.5 text-[10px] tracking-widest text-tibetan-bright">
              西南山地
            </span>
          </div>

          <p className="mt-2 text-xs leading-6 text-celadon/80">
            大凉山中，彝人以木为胎、以漆为衣，在餐具与酒器上刻下山川与图腾。
            <span className="text-celadon/60">风格粗犷有力，直线几何居多，寓意驱灾祈福、丰年永续。</span>
          </p>

          {/* 三色信仰 */}
          <div className="mt-3">
            <p className="mb-1.5 text-[11px] tracking-[0.3em] text-imperial-soft/90">三色信仰</p>
            <div className="flex gap-2">
              {TRI_COLOR.map((c) => (
                <div key={c.name} className="flex flex-1 items-center gap-2 rounded-sm border hairline bg-black/30 px-2.5 py-1.5">
                  <span
                    className="h-5 w-5 rounded-full"
                    style={{
                      backgroundColor: c.color,
                      boxShadow: c.ring ? 'inset 0 0 0 1px rgba(232,184,75,0.5)' : 'none',
                    }}
                  />
                  <span className="text-[11px] text-celadon/85">
                    {c.name} · {c.mean}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* 纹样来源 */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {['山', '虎', '火', '几何回纹'].map((tag) => (
              <span key={tag} className="rounded-sm bg-imperial/15 px-2 py-1 text-[10px] tracking-widest text-imperial-soft">
                # {tag}
              </span>
            ))}
          </div>

          <p className="mt-3 text-[10px] tracking-widest text-celadon/50">木胎漆器 · 悬停看注释 · 点击看纹样</p>
          <div className="mt-2 grid min-h-0 flex-1 grid-cols-4 gap-2">
            {YI_ARTIFACTS.map((a) => (
              <ArtifactCard key={a.id} artifact={a} onOpen={setOpened} />
            ))}
          </div>
        </Column>

        {/* 右：藏族吉祥八宝 */}
        <Column side="tb">
          <div className="flex items-center gap-3">
            <h3 className="font-cal text-2xl text-paper">藏族吉祥八宝</h3>
            <span className="rounded-full border border-imperial/50 px-2 py-0.5 text-[10px] tracking-widest text-imperial-soft">
              雪域高原
            </span>
          </div>

          <p className="mt-2 text-xs leading-6 text-celadon/80">
            寺院壁画、唐卡与藏式织物之间，八宝汇聚成一整套吉祥语汇。
            <span className="text-celadon/60">曲线柔美、金光勾线，寄寓的是精神祈福与觉悟圆满。</span>
          </p>

          {/* 八宝符号 */}
          <div className="mt-3">
            <p className="mb-1.5 text-[11px] tracking-[0.3em] text-imperial-soft/90">八宝符号</p>
            <div className="grid grid-cols-4 gap-1.5">
              {EIGHT_TREASURES.map((t) => (
                <div key={t.name} className="rounded-sm border hairline bg-black/30 px-1 py-1.5 text-center">
                  <p className="text-[11px] text-paper/90">{t.name}</p>
                  <p className="text-[9px] text-celadon/60">{t.mean}</p>
                </div>
              ))}
            </div>
          </div>

          <p className="mt-3 text-[10px] leading-relaxed text-celadon/55">
            多绘于唐卡、寺院壁画与藏式织物；每一件法器，都是一句可视化的祈愿。
          </p>

          <p className="mt-3 text-[10px] tracking-widest text-celadon/50">寺院器物 · 悬停看注释 · 点击看纹样</p>
          <div className="mt-2 grid min-h-0 flex-1 grid-cols-4 gap-2">
            {TB_ARTIFACTS.map((a) => (
              <ArtifactCard key={a.id} artifact={a} onOpen={setOpened} />
            ))}
          </div>
        </Column>
      </div>

      {/* 放大弹窗 */}
      <Modal open={opened !== null} onClose={() => setOpened(null)} label={opened?.name}>
        {opened && pattern && (
          <div className="flex flex-col items-center gap-4 pt-2 sm:flex-row">
            <div className="gold-frame flex h-64 w-64 flex-shrink-0 items-center justify-center rounded-sm bg-[#0D0906] p-4">
              <PatternView pattern={pattern} stage={2} className="h-full w-full" />
            </div>
            <div className="flex-1">
              <p className="text-[10px] tracking-[0.4em] text-celadon/60">{pattern.pinyin}</p>
              <h4 className="mt-1 font-cal text-3xl text-imperial">{opened.name}</h4>
              <p className="mt-1 text-xs tracking-widest text-tibetan-bright">器身纹样：{pattern.name} · {pattern.meaning}</p>
              <p className="mt-3 text-sm leading-7 text-celadon/85">{opened.note}</p>
              <p className="mt-3 text-sm leading-7 text-celadon/85">{pattern.summary}</p>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
