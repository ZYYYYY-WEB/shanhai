import type { CSSProperties, ReactNode } from 'react';

export interface FragColors {
  c1: string;
  c2: string;
  cl: string;
}

export interface FragmentDef {
  id: string;
  name: string;
  origin: string;
  node: (colors: FragColors) => ReactNode;
}

/** 单个回旋纹单元（漆器边饰拆出） */
function MeanderCell({ c1, c2, cl }: FragColors) {
  return (
    <g>
      <rect x={12} y={12} width={76} height={76} fill="none" stroke={cl} strokeWidth={9} />
      <rect x={28} y={28} width={44} height={44} fill="none" stroke={cl} strokeWidth={9} />
      <rect x={40} y={40} width={20} height={20} fill={c1} />
      <rect x={12} y={12} width={10} height={10} fill={c2} />
    </g>
  );
}

/** 小火纹 */
function MiniFire({ c1, c2, cl }: FragColors) {
  return (
    <g>
      <path
        d="M50 8 C62 30 80 40 76 62 C73 80 50 92 50 92 C50 92 27 80 24 62 C20 40 38 30 50 8 Z"
        fill={c1}
        stroke={cl}
        strokeWidth={3.5}
        strokeLinejoin="round"
      />
      <path
        d="M50 34 C58 48 66 54 63 66 C61 77 50 84 50 84 C50 84 39 77 37 66 C34 54 42 48 50 34 Z"
        fill={c2}
      />
    </g>
  );
}

/** 小莲花 */
function MiniLotus({ c1, c2, cl }: FragColors) {
  return (
    <g>
      <path
        d="M50 10 C46 30 34 40 20 44 C34 50 44 60 50 80 C56 60 66 50 80 44 C66 40 54 30 50 10 Z"
        fill={c1}
        stroke={cl}
        strokeWidth={3}
        strokeLinejoin="round"
      />
      <path d="M50 28 C40 42 28 48 16 49 C30 56 42 66 50 80 C58 66 70 56 84 49 C72 48 60 42 50 28 Z" fill={c2} opacity={0.9} />
      <path d="M16 84 H84 L76 92 H24 Z" fill={c2} stroke={cl} strokeWidth={2.5} strokeLinejoin="round" />
    </g>
  );
}

/** 小吉祥结 */
function MiniKnot({ c1, cl }: FragColors) {
  return (
    <g>
      <rect x={20} y={20} width={60} height={60} rx={5} fill="none" stroke={cl} strokeWidth={8} />
      <rect x={33} y={33} width={34} height={34} rx={3} fill="none" stroke={cl} strokeWidth={7} />
      <g fill="none" stroke={cl} strokeWidth={7} strokeLinecap="round">
        <path d="M20 38 H8 V62 H20 M80 38 H92 V62 H80 M38 20 V8 H62 V20 M38 80 V92 H62 V80" />
      </g>
      <circle cx={50} cy={50} r={5} fill={c1} />
    </g>
  );
}

/** 小金鱼（双鱼） */
function MiniFish({ c1, c2, cl }: FragColors) {
  return (
    <g>
      <path d="M10 44 C22 32 38 32 48 44 C38 56 22 56 10 44 Z" fill={c1} stroke={cl} strokeWidth={3} strokeLinejoin="round" />
      <path d="M90 44 C78 32 62 32 52 44 C62 56 78 56 90 44 Z" fill={c1} stroke={cl} strokeWidth={3} strokeLinejoin="round" />
      <path d="M10 44 L4 33 V55 Z M90 44 L96 33 V55 Z" fill={c2} stroke={cl} strokeWidth={2.5} strokeLinejoin="round" />
      <circle cx={42} cy={41} r={2.8} fill={cl} />
      <circle cx={58} cy={41} r={2.8} fill={cl} />
    </g>
  );
}

export const FRAGMENTS: FragmentDef[] = [
  { id: 'f-meander', name: '回纹单元', origin: '彝族漆器', node: (c) => <MeanderCell {...c} /> },
  { id: 'f-fire', name: '火纹', origin: '彝族漆器', node: (c) => <MiniFire {...c} /> },
  { id: 'f-lotus', name: '莲花', origin: '藏族八宝', node: (c) => <MiniLotus {...c} /> },
  { id: 'f-knot', name: '吉祥结', origin: '藏族八宝', node: (c) => <MiniKnot {...c} /> },
  { id: 'f-fish', name: '金鱼', origin: '藏族八宝', node: (c) => <MiniFish {...c} /> },
];

interface FragmentSvgProps {
  fragment: FragmentDef;
  colors: FragColors;
  className?: string;
  style?: CSSProperties;
}

export function FragmentSvg({ fragment, colors, className, style }: FragmentSvgProps) {
  return (
    <svg viewBox="0 0 100 100" className={className} style={{ overflow: 'visible', ...style }}>
      {fragment.node(colors)}
    </svg>
  );
}
