import type { ReactNode } from 'react';

const YL = { stroke: '#E8B84B', fill: 'none' } as const;
const TL = { stroke: '#F2D078', fill: 'none' } as const;

/* ========== 彝族木胎漆器 ========== */

/** 漆碗（腹部回纹带） */
function YiBowl() {
  return (
    <g>
      <path d="M12 40 Q50 84 88 40 Z" fill="#1A1209" stroke="#E8B84B" strokeWidth={2.5} />
      <ellipse cx={50} cy={40} rx={38} ry={7} fill="#241708" stroke="#C0392B" strokeWidth={2.5} />
      <path d="M18 48 l5 -5 l5 5 l5 -5 l5 5 l5 -5 l5 5 l5 -5 l5 5 l5 -5" {...YL} strokeWidth={2} />
      <path d="M38 74 H62 L58 80 H42 Z" fill="#C0392B" />
    </g>
  );
}

/** 高足漆酒杯 */
function YiGoblet() {
  return (
    <g>
      <path d="M30 22 H70 L62 50 H38 Z" fill="#1A1209" stroke="#E8B84B" strokeWidth={2.5} />
      <ellipse cx={50} cy={22} rx={20} ry={4.5} fill="#241708" stroke="#C0392B" strokeWidth={2.2} />
      <rect x={47} y={50} width={6} height={26} fill="#C0392B" />
      <path d="M34 78 H66 L60 86 H40 Z" fill="#E8B84B" />
      <path d="M34 34 H66 M37 42 H63" {...YL} strokeWidth={2} />
    </g>
  );
}

/** 扁圆漆木盒（盖面火纹） */
function YiBox() {
  return (
    <g>
      <ellipse cx={50} cy={72} rx={38} ry={12} fill="#1A1209" stroke="#C0392B" strokeWidth={2.5} />
      <path d="M12 72 V52 Q50 30 88 52 V72" fill="#241708" stroke="#E8B84B" strokeWidth={2.5} />
      <path d="M50 38 l6 9 l-3 0 l4 8 H43 l4 -8 h-3 Z" fill="#C0392B" />
      <circle cx={50} cy={50} r={2.6} fill="#E8B84B" />
      <path d="M20 62 Q50 72 80 62" {...YL} strokeWidth={1.8} />
    </g>
  );
}

/** 扁腹漆酒壶（牛角纹） */
function YiFlask() {
  return (
    <g>
      <path d="M32 24 H68 V30 Q82 40 82 56 Q82 78 50 82 Q18 78 18 56 Q18 40 32 30 Z" fill="#1A1209" stroke="#E8B84B" strokeWidth={2.5} />
      <path d="M68 46 Q86 46 86 60 Q86 70 72 70" {...YL} strokeWidth={2.5} />
      <rect x={40} y={16} width={20} height={9} rx={2} fill="#C0392B" />
      <path d="M34 48 Q42 42 48 50 M66 48 Q58 42 52 50" stroke="#C0392B" strokeWidth={2.4} fill="none" />
      <circle cx={50} cy={62} r={4} fill="#E8B84B" />
    </g>
  );
}

/* ========== 藏族寺院器物 ========== */

/** 唐卡卷轴（画心莲花） */
function TbThangka() {
  return (
    <g>
      <rect x={26} y={18} width={48} height={62} rx={2} fill="#5A1714" stroke="#F2D078" strokeWidth={2.5} />
      <rect x={31} y={24} width={38} height={50} fill="#7A201C" />
      <line x1={20} y1={18} x2={80} y2={18} stroke="#E8B84B" strokeWidth={4} />
      <line x1={20} y1={80} x2={80} y2={80} stroke="#E8B84B" strokeWidth={4} />
      <path d="M50 34 C47 42 42 46 37 48 C43 51 47 55 50 63 C53 55 57 51 63 48 C58 46 53 42 50 34 Z" fill="#E8B84B" />
      <path d="M44 68 H56 L53 72 H47 Z" fill="#F2D078" />
    </g>
  );
}

/** 转经筒 */
function TbPrayerWheel() {
  return (
    <g>
      <rect x={28} y={22} width={44} height={44} rx={3} fill="#7A201C" stroke="#F2D078" strokeWidth={2.5} />
      <ellipse cx={50} cy={22} rx={22} ry={5} fill="#9E2B25" stroke="#F2D078" strokeWidth={2} />
      <path d="M34 34 H66 M34 54 H66 M34 40 Q50 46 66 40 M34 48 Q50 54 66 48" {...TL} strokeWidth={1.8} />
      <rect x={47} y={66} width={6} height={14} fill="#C8923A" />
      <path d="M53 70 q8 4 6 14" {...TL} strokeWidth={1.6} />
      <circle cx={59} cy={86} r={3} fill="#E8B84B" />
    </g>
  );
}

/** 法铃 */
function TbBell() {
  return (
    <g>
      <path d="M34 30 Q50 24 66 30 L74 66 Q50 78 26 66 Z" fill="#7A201C" stroke="#F2D078" strokeWidth={2.5} />
      <rect x={44} y={20} width={12} height={9} rx={2} fill="#E8B84B" />
      <circle cx={50} cy={17} r={4} fill="#F2D078" />
      <path d="M32 54 H68 M38 62 Q50 68 62 62" {...TL} strokeWidth={2} />
      <circle cx={50} cy={72} r={3.5} fill="#F2D078" />
    </g>
  );
}

/** 藏式执壶（吉祥结饰） */
function TbTeapot() {
  return (
    <g>
      <path d="M30 34 H70 Q80 34 80 46 V64 Q80 76 50 78 Q20 76 20 64 V46 Q20 34 30 34 Z" fill="#7A201C" stroke="#F2D078" strokeWidth={2.5} />
      <path d="M20 46 Q6 48 8 62" {...TL} strokeWidth={2.5} />
      <path d="M80 46 Q92 44 90 32" {...TL} strokeWidth={2.5} />
      <rect x={42} y={25} width={16} height={8} rx={2} fill="#E8B84B" />
      <rect x={40} y={48} width={20} height={16} rx={2} {...TL} strokeWidth={2} />
      <path d="M44 52 H56 M50 48 V64" {...TL} strokeWidth={1.6} />
    </g>
  );
}

export interface ArtifactDef {
  id: string;
  name: string;
  note: string;
  patternId: string;
  node: ReactNode;
}

export const YI_ARTIFACTS: ArtifactDef[] = [
  { id: 'a-bowl', name: '木胎漆碗', note: '木胎髹黑漆，碗腹以红黄绘回纹带，盛食也盛祝福。', patternId: 'yi-meander', node: <YiBowl /> },
  { id: 'a-cup', name: '高足漆酒杯', note: '高足敛口，红黄环带相间，敬酒于火塘与先祖。', patternId: 'yi-fire', node: <YiGoblet /> },
  { id: 'a-box', name: '扁圆漆盒', note: '盖面火纹居中，藏食盒亦是火塘边的礼器。', patternId: 'yi-fire', node: <YiBox /> },
  { id: 'a-flask', name: '漆酒壶', note: '扁腹便携，牛角纹护身，山地行旅不离身。', patternId: 'yi-horn', node: <YiFlask /> },
];

export const TB_ARTIFACTS: ArtifactDef[] = [
  { id: 'a-thangka', name: '唐卡卷轴', note: '矿物彩绘于布，莲花端坐画心，悬挂即是一方佛国。', patternId: 'tb-lotus', node: <TbThangka /> },
  { id: 'a-wheel', name: '转经筒', note: '筒内藏经卷，每转一周如诵经一遍，金纹随筒身流转。', patternId: 'tb-wheel', node: <TbPrayerWheel /> },
  { id: 'a-bell', name: '法铃', note: '铃身刻金纹，摇响时警醒无明，回荡于寺院经堂。', patternId: 'tb-bell', node: <TbBell /> },
  { id: 'a-pot', name: '藏式执壶', note: '长流高把，腹结吉祥结，酥油茶中亦有祈愿。', patternId: 'tb-knot', node: <TbTeapot /> },
];
