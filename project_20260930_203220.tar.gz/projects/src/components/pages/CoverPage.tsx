import { useEffect, type CSSProperties } from 'react';
import { findPattern } from '../patterns';

interface CoverPageProps {
  onEnter: () => void;
  goNext: () => void;
}

export function CoverPage({ onEnter, goNext }: CoverPageProps) {
  useEffect(() => {
    onEnter();
  }, [onEnter]);

  const tiger = findPattern('yi-tiger');
  const knot = findPattern('tb-knot');

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
      {/* 双纹样底纹叠加（半虚化） */}
      <div className="pointer-events-none absolute inset-0" data-decor>
        <svg
          viewBox="0 0 100 100"
          className="anim-drift absolute -left-24 top-1/2 h-[78vh] -translate-y-1/2 opacity-[0.16] blur-[3px]"
          style={
            {
              '--a': '#3A1410',
              '--b': '#5A3E16',
              '--l': '#8C4A22',
              '--ink': '#0D0906',
            } as CSSProperties
          }
        >
          {tiger.layers.map((layer) => (
            <g key={layer.id}>{layer.node}</g>
          ))}
        </svg>
        <svg
          viewBox="0 0 100 100"
          className="anim-drift-reverse absolute -right-24 top-1/2 h-[78vh] -translate-y-1/2 opacity-[0.16] blur-[3px]"
          style={
            {
              '--a': '#5C3A12',
              '--b': '#4A1410',
              '--l': '#8A6428',
              '--ink': '#2A0F0D',
            } as CSSProperties
          }
        >
          {knot.layers.map((layer) => (
            <g key={layer.id}>{layer.node}</g>
          ))}
        </svg>
        <div className="absolute inset-0 bg-gradient-to-r from-lacquer-deep/70 via-transparent to-lacquer-deep/70" />
      </div>

      {/* 中央内容 */}
      <div className="relative z-10 flex flex-col items-center px-6 text-center">
        <p className="anim-emerge delay-1 mb-6 text-xs tracking-[0.7em] text-celadon/80">
          数 字 媒 体 创 意 大 赛 · 民 族 纹 样 赛 道
        </p>

        <h1 className="anim-emerge delay-2 font-cal text-[clamp(4rem,11vw,9.5rem)] leading-none text-paper drop-shadow-[0_6px_30px_rgba(0,0,0,0.8)]">
          山海<span className="text-imperial">纹</span>叙
        </h1>

        <div className="anim-emerge delay-2 mt-6 flex items-center gap-4">
          <span className="h-px w-14 bg-imperial/60" />
          <p className="font-deco text-base tracking-[0.35em] text-imperial-soft">
            藏 · 彝传统民族纹样数字交互展厅
          </p>
          <span className="h-px w-14 bg-imperial/60" />
        </div>

        <p className="anim-emerge delay-3 mt-10 max-w-xl text-sm leading-9 text-celadon/85">
          一方雪域，一方山地；
          <br />
          纹样是镌刻在器物之上的民族语言。
        </p>

        {/* 横向滑动引导 */}
        <button
          type="button"
          onClick={goNext}
          className="anim-emerge delay-4 group mt-14 flex items-center gap-3 text-celadon/80 transition-colors hover:text-imperial"
          aria-label="横向滑动浏览"
        >
          <span className="text-[11px] tracking-[0.4em]">向右滑动 · 启卷</span>
          <span className="anim-arrow">
            <svg width="46" height="20" viewBox="0 0 46 20" fill="none" stroke="currentColor" strokeWidth="1.4">
              <path d="M2 10 H40 M32 3 L40 10 L32 17" />
            </svg>
          </span>
        </button>
      </div>

      {/* 四角装饰 */}
      <div className="pointer-events-none absolute left-8 top-20 h-10 w-10 border-l border-t border-imperial/35" />
      <div className="pointer-events-none absolute right-8 top-20 h-10 w-10 border-r border-t border-imperial/35" />
      <div className="pointer-events-none absolute bottom-16 left-8 h-10 w-10 border-b border-l border-imperial/35" />
      <div className="pointer-events-none absolute bottom-16 right-8 h-10 w-10 border-b border-r border-imperial/35" />
    </div>
  );
}
