import { PatternView, findPattern } from '../patterns';

interface EndingPageProps {
  active: boolean;
  onReplay: () => void;
}

export function EndingPage({ active, onReplay }: EndingPageProps) {
  const tiger = findPattern('yi-tiger');
  const knot = findPattern('tb-knot');

  return (
    <div className="relative flex h-full w-full items-center justify-center overflow-hidden">
      {/* 背景双纹微光 */}
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center gap-40 opacity-[0.08]">
        <PatternView pattern={tiger} stage={2} className="h-[60vh]" />
        <PatternView pattern={knot} stage={2} className="h-[60vh]" />
      </div>
      <div className="absolute inset-0 bg-gradient-to-b from-lacquer-deep/60 via-transparent to-lacquer-deep/80" />

      <div className={`relative z-10 flex w-[min(900px,88vw)] flex-col items-center text-center ${active ? 'anim-emerge' : 'opacity-0'}`}>
        <p className="text-[10px] tracking-[0.6em] text-celadon/60">EPILOGUE · 结 语</p>

        <blockquote className="mt-8 font-cal text-[clamp(1.8rem,4vw,3.2rem)] leading-snug text-paper">
          民族纹样不是尘封的古董，
          <br />
          是<span className="text-imperial">活的文化符号</span>。
        </blockquote>

        <p className="mt-7 max-w-xl text-sm leading-8 text-celadon/75">
          从西南山地的火塘，到雪域高原的寺院；
          从木胎漆器的刻线，到数字屏幕的像素——
          当我们亲手拆解、重组这些纹样，它们便在当代继续生长。
        </p>

        {/* 作品信息 */}
        <div className="mt-12 grid w-full grid-cols-3 gap-px overflow-hidden rounded-sm border hairline bg-celadon/15 text-left">
          <div className="bg-lacquer/90 px-5 py-4">
            <p className="text-[10px] tracking-[0.3em] text-celadon/50">作品名称</p>
            <p className="mt-1.5 font-deco text-base text-imperial-soft">山海纹叙</p>
            <p className="text-[10px] text-celadon/55">藏彝民族传统纹样数字交互展厅</p>
          </div>
          <div className="bg-lacquer/90 px-5 py-4">
            <p className="text-[10px] tracking-[0.3em] text-celadon/50">参赛赛道</p>
            <p className="mt-1.5 text-sm text-paper">全国大学生数字媒体科技作品及创意竞赛</p>
            <p className="text-[10px] text-celadon/55">民族文化创新表达赛道</p>
          </div>
          <div className="bg-lacquer/90 px-5 py-4">
            <p className="text-[10px] tracking-[0.3em] text-celadon/50">小组成员</p>
            <p className="mt-1.5 text-sm text-paper">张滢潆 · 夏湘婷 · 王泽琛</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onReplay}
          className="mt-10 rounded-sm border border-imperial/50 px-6 py-2 text-[11px] tracking-[0.35em] text-imperial-soft transition hover:bg-tibetan-deep"
        >
          ↺ 重返序章
        </button>
      </div>
    </div>
  );
}
