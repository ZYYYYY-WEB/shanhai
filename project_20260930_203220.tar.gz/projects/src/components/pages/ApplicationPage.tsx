import type { ReactNode } from 'react';
import { PageHeader } from '../PageHeader';
import { FRAGMENTS, FragmentSvg } from './FragmentArt';
import type { FragColors } from './FragmentArt';

interface ApplicationPageProps {
  active: boolean;
}

interface ShowcaseDef {
  id: string;
  title: string;
  sub: string;
  fragmentId: string;
  colors: FragColors;
  /** 样机渲染：参数为纹样节点（已经按配色渲染好的 svg） */
  mockup: (art: ReactNode) => ReactNode;
}

const YI_COLORS: FragColors = { c1: '#C0392B', c2: '#E8B84B', cl: '#F2D078' };
const TB_COLORS: FragColors = { c1: '#E8B84B', c2: '#9E2B25', cl: '#F2D078' };

/* ---------- 样机 ---------- */

function BookmarkMockup(art: ReactNode) {
  return (
    <svg viewBox="0 0 100 160" className="h-full w-full">
      <path d="M12 6 H88 V150 L50 132 L12 150 Z" fill="#1A120C" stroke="#E8B84B" strokeWidth={2} />
      <circle cx={50} cy={20} r={5} fill="none" stroke="#F2D078" strokeWidth={2} />
      <foreignObject x={18} y={34} width={64} height={64}>
        <div style={{ width: '100%', height: '100%' }}>{art}</div>
      </foreignObject>
      <text x={50} y={118} textAnchor="middle" fontSize={10} fill="#F2D078" style={{ fontFamily: '"Ma Shan Zheng", cursive' }}>
        山海纹叙
      </text>
      <path d="M20 128 H80" stroke="#E8B84B" strokeWidth={1} strokeDasharray="3 3" />
    </svg>
  );
}

function PhoneCaseMockup(art: ReactNode) {
  return (
    <svg viewBox="0 0 100 160" className="h-full w-full">
      <rect x={10} y={4} width={80} height={152} rx={14} fill="#731C19" stroke="#E8B84B" strokeWidth={2} />
      <rect x={16} y={12} width={68} height={136} rx={9} fill="#5A1714" />
      <circle cx={50} cy={20} r={2.5} fill="#2A0F0D" />
      <foreignObject x={22} y={34} width={56} height={56}>
        <div style={{ width: '100%', height: '100%' }}>{art}</div>
      </foreignObject>
      <g fill="none" stroke="#E8B84B" strokeWidth={1.6}>
        <path d="M20 104 Q50 112 80 104 M20 118 Q50 126 80 118 M20 132 Q50 140 80 132" />
      </g>
    </svg>
  );
}

function PosterMockup(art: ReactNode) {
  return (
    <svg viewBox="0 0 110 150" className="h-full w-full">
      <rect x={6} y={6} width={98} height={138} fill="#15100C" stroke="#E8B84B" strokeWidth={2} />
      <text x={55} y={34} textAnchor="middle" fontSize={15} fill="#F4ECD8" style={{ fontFamily: '"Ma Shan Zheng", cursive' }}>
        山 海 纹 叙
      </text>
      <line x1={35} y1={44} x2={75} y2={44} stroke="#9E2B25" strokeWidth={2} />
      <foreignObject x={20} y={52} width={70} height={70}>
        <div style={{ width: '100%', height: '100%' }}>{art}</div>
      </foreignObject>
      <text x={55} y={136} textAnchor="middle" fontSize={5.4} fill="#B9C7C6" letterSpacing="0.6" style={{ fontFamily: '"Noto Sans SC", sans-serif' }}>
        藏彝纹样数字展厅
      </text>
    </svg>
  );
}

function ApparelMockup(art: ReactNode) {
  return (
    <svg viewBox="0 0 140 150" className="h-full w-full">
      <path
        d="M48 12 L20 30 L8 52 L24 64 L24 138 L116 138 L116 64 L132 52 L120 30 L92 12 Q70 26 48 12 Z"
        fill="#E9E2D2"
        stroke="#8FA2A1"
        strokeWidth={2}
        strokeLinejoin="round"
      />
      <path d="M48 12 Q70 30 92 12 Q82 22 70 22 Q58 22 48 12 Z" fill="#C7BDAC" />
      <foreignObject x={45} y={52} width={50} height={50}>
        <div style={{ width: '100%', height: '100%' }}>{art}</div>
      </foreignObject>
    </svg>
  );
}

const SHOWCASES: ShowcaseDef[] = [
  { id: 's-bookmark', title: '文创书签', sub: '火纹入卷，夹进每一页阅读', fragmentId: 'f-fire', colors: YI_COLORS, mockup: BookmarkMockup },
  { id: 's-phone', title: '手机壳', sub: '吉祥结随身影相伴', fragmentId: 'f-knot', colors: TB_COLORS, mockup: PhoneCaseMockup },
  { id: 's-poster', title: '展览海报', sub: '莲花与书法并置的视觉长卷', fragmentId: 'f-lotus', colors: TB_COLORS, mockup: PosterMockup },
  { id: 's-apparel', title: '服饰印花', sub: '回纹穿上身，纹样即态度', fragmentId: 'f-meander', colors: YI_COLORS, mockup: ApparelMockup },
];

export function ApplicationPage({ active }: ApplicationPageProps) {
  return (
    <div className={`flex h-full flex-col px-10 pb-16 pt-20 ${active ? 'anim-emerge-soft' : 'opacity-0'}`}>
      <PageHeader
        index="肆"
        title="现代应用展示"
        pinyin="CONTEMPORARY APPLICATION"
        desc="传统纹样走出器物，融入当代青年的生活：书签、手机壳、海报与服饰之间。"
      />

      <div className="mt-4 grid min-h-0 flex-1 grid-cols-4 gap-5">
        {SHOWCASES.map((showcase) => {
          const fragment = FRAGMENTS.find((f) => f.id === showcase.fragmentId) ?? FRAGMENTS[0];
          return (
            <figure
              key={showcase.id}
              className="group relative flex flex-col items-center justify-end overflow-hidden rounded-sm border hairline bg-gradient-to-b from-[#1C150F] to-[#120D09] p-4 transition-all duration-500 hover:border-imperial/60 hover:shadow-[0_24px_70px_rgba(0,0,0,0.6)]"
            >
              <div className="flex min-h-0 flex-1 items-center transition-transform duration-500 ease-ritual group-hover:scale-[1.12]">
                <span className="block h-full max-h-[52vh]">
                  {showcase.mockup(
                    <FragmentSvg fragment={fragment} colors={showcase.colors} className="h-full w-full" />,
                  )}
                </span>
              </div>
              <figcaption className="mt-3 text-center">
                <p className="font-deco text-lg tracking-[0.25em] text-paper">{showcase.title}</p>
                <p className="mt-1 text-[11px] tracking-wider text-celadon/60">{showcase.sub}</p>
              </figcaption>
              <span className="pointer-events-none absolute inset-0 bg-imperial/0 transition-colors duration-500 group-hover:bg-imperial/[0.04]" />
            </figure>
          );
        })}
      </div>

      <p className="mt-4 text-center text-xs tracking-[0.3em] text-celadon/55">
        从木胎漆器与寺院壁画，到青年掌心与肩头 —— 纹样从未停止生长
      </p>
    </div>
  );
}
