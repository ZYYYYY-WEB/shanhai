interface PageHeaderProps {
  index: string;
  title: string;
  pinyin: string;
  desc?: string;
  accent?: 'red' | 'gold';
}

export function PageHeader({ index, title, pinyin, desc, accent = 'gold' }: PageHeaderProps) {
  const accentColor = accent === 'red' ? 'text-tibetan-bright' : 'text-imperial';
  return (
    <div className="flex items-end gap-5">
      <span className={`font-cal text-5xl leading-none ${accentColor}`}>{index}</span>
      <div>
        <p className="text-[10px] tracking-[0.5em] text-celadon/60">{pinyin}</p>
        <h2 className="whitespace-nowrap font-cal text-3xl text-paper">{title}</h2>
      </div>
      {desc && <p className="ml-4 max-w-md pb-1 text-xs leading-relaxed text-celadon/70">{desc}</p>}
    </div>
  );
}
