import { useCallback, useEffect, useRef, useState } from 'react';
import { NavDots } from './components/NavDots';
import { CoverPage } from './components/pages/CoverPage';
import { OriginPage } from './components/pages/OriginPage';
import { LabPage } from './components/pages/LabPage';
import { WorkshopPage } from './components/pages/WorkshopPage';
import { ApplicationPage } from './components/pages/ApplicationPage';
import { EndingPage } from './components/pages/EndingPage';

const PAGE_LABELS = ['序章', '溯源', '解构', '工坊', '新生', '结语'];

export default function App() {
  const [page, setPage] = useState(0);
  const [entered, setEntered] = useState(false);
  const lockedRef = useRef(false);
  const touchStartXRef = useRef<number | null>(null);
  const pageCount = PAGE_LABELS.length;

  const goTo = useCallback(
    (target: number) => {
      if (lockedRef.current) return;
      const next = Math.max(0, Math.min(pageCount - 1, target));
      setPage((prev) => {
        if (prev === next) return prev;
        lockedRef.current = true;
        window.setTimeout(() => {
          lockedRef.current = false;
        }, 850);
        if (typeof window !== 'undefined' && window.location.hash !== `#${next}`) {
          window.history.pushState(null, '', `#${next}`);
        }
        return next;
      });
    },
    [pageCount],
  );

  // hash -> state 同步：初始化直达 + 浏览器前进/后退 + 同源 hash 导航
  useEffect(() => {
    const syncFromHash = () => {
      const raw = Number(window.location.hash.replace('#', ''));
      if (Number.isInteger(raw) && raw >= 0 && raw < pageCount) {
        setPage(raw);
      }
    };
    syncFromHash();
    window.addEventListener('hashchange', syncFromHash);
    return () => window.removeEventListener('hashchange', syncFromHash);
  }, [pageCount]);

  // 鼠标滚轮：纵向滚动转横向翻页
  useEffect(() => {
    const onWheel = (e: WheelEvent) => {
      const target = e.target as HTMLElement | null;
      if (target?.closest('[data-no-slide]')) return;
      if (Math.abs(e.deltaY) < 12 && Math.abs(e.deltaX) < 12) return;
      const delta = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
      goTo(page + (delta > 0 ? 1 : -1));
    };
    window.addEventListener('wheel', onWheel, { passive: true });
    return () => window.removeEventListener('wheel', onWheel);
  }, [page, goTo]);

  // 触摸滑动
  useEffect(() => {
    const onTouchStart = (e: TouchEvent) => {
      touchStartXRef.current = e.touches[0].clientX;
    };
    const onTouchEnd = (e: TouchEvent) => {
      const start = touchStartXRef.current;
      if (start === null) return;
      const dx = e.changedTouches[0].clientX - start;
      touchStartXRef.current = null;
      if (Math.abs(dx) > 48) {
        goTo(page + (dx < 0 ? 1 : -1));
      }
    };
    window.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchend', onTouchEnd, { passive: true });
    return () => {
      window.removeEventListener('touchstart', onTouchStart);
      window.removeEventListener('touchend', onTouchEnd);
    };
  }, [page, goTo]);

  // 键盘方向键
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'PageDown') {
        e.preventDefault();
        goTo(page + 1);
      } else if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
        e.preventDefault();
        goTo(page - 1);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [page, goTo]);

  return (
    <div className="grain-bg vignette relative h-full w-full overflow-hidden">
      {/* 页眉品牌 */}
      <header
        className={`fixed left-0 right-0 top-0 z-[70] flex items-center justify-between px-8 py-5 transition-opacity duration-1000 ${
          page === 0 && !entered ? 'opacity-0' : 'opacity-100'
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="font-cal text-2xl text-imperial">山海纹叙</span>
          <span className="hidden text-[11px] tracking-[0.35em] text-celadon/70 sm:inline">
            SHAN HAI WEN XU
          </span>
        </div>
        <span className="text-[11px] tracking-[0.3em] text-celadon/60">
          藏彝民族传统纹样数字交互展厅
        </span>
      </header>

      {/* 横向长卷 */}
      <div
        className="flex h-full"
        style={{
          transform: `translate3d(${-page * 100}vw, 0, 0)`,
          transition: 'transform 800ms cubic-bezier(0.22, 1, 0.36, 1)',
        }}
      >
        <section className="relative h-full w-screen flex-shrink-0">
          <CoverPage onEnter={() => setEntered(true)} goNext={() => goTo(1)} />
        </section>
        <section className="relative h-full w-screen flex-shrink-0">
          <OriginPage active={page === 1} />
        </section>
        <section className="relative h-full w-screen flex-shrink-0">
          <LabPage active={page === 2} stageHint={page} />
        </section>
        <section className="relative h-full w-screen flex-shrink-0">
          <WorkshopPage active={page === 3} />
        </section>
        <section className="relative h-full w-screen flex-shrink-0">
          <ApplicationPage active={page === 4} />
        </section>
        <section className="relative h-full w-screen flex-shrink-0">
          <EndingPage active={page === 5} onReplay={() => goTo(0)} />
        </section>
      </div>

      <NavDots count={pageCount} current={page} labels={PAGE_LABELS} onJump={goTo} />

      {/* 左右翻页箭头（非封面页） */}
      {page > 0 && (
        <button
          type="button"
          onClick={() => goTo(page - 1)}
          aria-label="上一页"
          className="fixed left-5 top-1/2 z-[60] -translate-y-1/2 text-celadon/50 transition hover:text-imperial"
        >
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M15 5 L8 12 L15 19" />
          </svg>
        </button>
      )}
      {page < pageCount - 1 && (
        <button
          type="button"
          onClick={() => goTo(page + 1)}
          aria-label="下一页"
          className="fixed right-5 top-1/2 z-[60] -translate-y-1/2 text-celadon/50 transition hover:text-imperial"
        >
          <svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
            <path d="M9 5 L16 12 L9 19" />
          </svg>
        </button>
      )}
    </div>
  );
}
